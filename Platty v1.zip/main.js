/******************
 * Main js file for platformer game
 * Created by Hunter Chapman
 * Level 2 Programming assesment
 ******************/
 
// Constants
const SPRITEYOFFSET = 17;
const CAMSPRITEYOFFSET = 14;
const SPRITEWIDTHOFFSET = 2;
const WINDOWHEIGHTOFFSET = 291;
const SCALEFACTOR = 5;
const HEROFRAMEDELAY = 8;
const JUMPTOTALFRAMES = 5;
const JUMPHEIGHT = 15;
const HEROSPEED = 2.5;
const TILESIZE = 2;
const TILEXOFFSET = 400;

// Predefines
let hero;
let floor;
let spriteSheetHero;
let bgImage;
let plattyBackground;
let nameHasBeenInputted = false;
let heroIsJumping = false;
let jumpAniDone = false;
let riseAnimationPlayed = false;
let jumpFrameCount = 0;
let propTiles;
let groundTiles;
let swampTiles;
let level1Tiles;
let airTile;
let makeCameraStatic = false;


/* Preload function, currently just loading images, 
 * tilesheets, spritesheets, etc */
function preload() 
{
	spriteSheetHero = loadImage('/resources/questKid.png');
	bgImage = loadImage('/resources/loginPageBackground.jpeg');
	plattyBackground = loadImage('/resources/gameBackground.png');
	swampTiles = loadImage('/resources/tilesets/swampTiles.png');
	groundTiles = loadImage('/resources/tilesets/groundTiles.png');
	propTiles = loadImage('/resources/tilesets/propTiles.png');
	airTile = loadImage('/resources/tilesets/air.png');
}


// Setup function, creates canvas, sprites, and assigns animations
function setup() 
{ 
    // Get window height before it is upscaled by the 'pixelated x5' in create canvas
    let unalteredWindowHeight = (windowHeight - WINDOWHEIGHTOFFSET) / SCALEFACTOR;
    let unalteredWindowWidth = windowWidth / SCALEFACTOR;
    
    // Create canvas
    cnv = new Canvas(unalteredWindowWidth, unalteredWindowHeight, 'pixelated x5');
    allSprites.pixelPerfect = true;
    console.log("Canvas is (width/height): " + canvas.w + "/" + canvas.h);
    
    // Create sprite
    hero = new Sprite(unalteredWindowWidth / SPRITEWIDTHOFFSET, unalteredWindowHeight - SPRITEYOFFSET, 32, 32, 'k');
    console.log("Hero's (sprite) X/Y coordinates are: " + hero.x + "/" + hero.y);
    hero.rotationLock = true;
    hero.spriteSheet = spriteSheetHero;
    hero.anis.offset.x = SPRITEWIDTHOFFSET;
    hero.anis.frameDelay = HEROFRAMEDELAY;
    world.gravity.y = 9.8;
	
	// Create sprite animation and assign sleeping ani to sprite
	hero.addAnis({
		run: { row: 0, frames: 8 },
		jump: { row: 1, frames: 6 },
		roll: { row: 2, frames: 5, frameDelay: 14 },
		turn: { row: 3, frames: 7 },
		stand: { row: 3, frames: 1 },
		sleeping: { row: 21, frames: 10 },
		riseFromGround: { row: 23, frames: 6 }
	});
	
    hero.changeAni('sleeping');
    hero.w = 13;
    hero.h = 28;
    hero.friction = 0;
    hero.wallCollisionHappened = false;
}

// Game start Function, called on click of play button, resizes-
// canvas, adds background, removes html elements 
function startGame() {
    // First, check if a name has been inputted
    if (!nameInputted()) {
        document.getElementById("userNameHint").textContent = "Please enter a name containing only letters";
    }
    else if (nameInputted()) {
    // Removes Header and play button elements, they're being-
    // removed instead of hidden as when theyre hidden the canvas-
    // can't use the full screen size without scrolling otherwise
    removeElement("htmlElements");
    
    //Create new variables with accurate window width/height
    let resizedWindowHeight = windowHeight / SCALEFACTOR;
    let resizedWindowWidth = windowWidth / SCALEFACTOR;
    
   
    bgImage = plattyBackground;
    allSprites.pixelPerfect = true;
    console.log("Canvas has been resized, game started");
    // Reposition sprite 'hero' to center of new view
    hero.position.x = resizedWindowWidth / SPRITEWIDTHOFFSET;
    hero.position.y = resizedWindowHeight - SPRITEYOFFSET;
    hero.changeAni('riseFromGround');
	hero.animation.looping = false;
	riseAnimationPlayed = true;
	// Calls the function that creates the tiles
    startLevel1();
     // Remove canvas and recreate it with new values because
    // resizeCanvas() doesn't work for some reason
    canvas.remove()
    cnv = new Canvas(resizedWindowWidth, resizedWindowHeight, 'pixelated x5');
    hero.cameraFollowY = true;
    hero.cameraFollowX = true;
    hero.collider = 'dynamic';
    }
}

function startLevel1() {
    //Create new variables with accurate window width/height
    let resizedWindowHeight = windowHeight / SCALEFACTOR;
    let resizedWindowWidth = windowWidth / SCALEFACTOR;
    let xCoord = hero.position.x - TILEXOFFSET;
    let yCoord = resizedWindowHeight - 15;
    console.log("creating tiles for first level")
    swampGrass = new Group();
    swampGrass.tile = 's';
    swampGrass.collider = 'static';
    swampGrass.spriteSheet = swampTiles;
    swampGrass.addAni({ w: 16, h: 16, row: 0, col: 1 });
    
    swampDirt = new Group();
    swampDirt.tile = 'd';
    swampDirt.collider = 'static';
    swampDirt.spriteSheet = swampTiles;
    swampDirt.addAni({ w: 16, h: 16, row: 1, col: 1 });
    
    grassLeftCorner = new Group();
    grassLeftCorner.tile = 'l';
    grassLeftCorner.collider = 'static';
    grassLeftCorner.spriteSheet = swampTiles;
    grassLeftCorner.addAni({ w: 16, h: 16, row: 0, col: 5 });
    
    grassBottomLeftCorner = new Group();
    grassBottomLeftCorner.tile = 'L';
    grassBottomLeftCorner.collider = 'static';
    grassBottomLeftCorner.spriteSheet = swampTiles;
    grassBottomLeftCorner.addAni({ w: 16, h: 16, row: 4, col: 7 });
    
    grassRightCorner = new Group();
    grassRightCorner.tile = 'r';
    grassRightCorner.collider = 'static';
    grassRightCorner.spriteSheet = swampTiles;
    grassRightCorner.addAni({ w: 16, h: 16, row: 0, col: 0 });
    
    grassBottomRightCorner = new Group();
    grassBottomRightCorner.tile = 'R';
    grassBottomRightCorner.collider = 'static';
    grassBottomRightCorner.spriteSheet = swampTiles;
    grassBottomRightCorner.addAni({ w: 16, h: 16, row: 4, col: 10 });
    
    leftWallCheck = new Group();
    leftWallCheck.tile = 'a';
    leftWallCheck.collider = 'none';
    leftWallCheck.image = airTile;
    leftWallCheck.w = 16;
    leftWallCheck.h = 16;
    
    cameraDisable = new Group();
    cameraDisable.tile = 'k';
    cameraDisable.collider = 'none';
    cameraDisable.image = airTile;
    cameraDisable.w = 16;
    cameraDisable.h = 16;
    
    air = new Group();
    air.tile = 'A';
    air.collider = 'static';
    air.image = airTile;
    air.w = 28;
    air.h = 16;
    
    level1Tiles = new Tiles(
        [
            '.......A........ka............................................................s',
            '.......A........ka............................................................s',
            '.......A........ka............................................................s',
            'sssssssssssssssssssssssssssssssssssssssssl..rssssssl...rsssssl.....rssssssssss',
            'dddddddddddddddddddddddddddddddddddddddddLssRddddddLsssRdddddLsssssRdddddddddd',
            'dddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddd',
            'dddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddd',
            'dddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddd',
            'dddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddd',
            'dddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddd',
            'dddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddd',
            'dddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddd'
        ],
        xCoord, yCoord,
        16, 16
    );
}

function windowResized() {
    // Create new variables with accurate window width/height
    let resizedWindowHeight = windowHeight / SCALEFACTOR;
    let resizedWindowWidth = windowWidth / SCALEFACTOR;
    let heroPreviousX = hero.position.x;
    let heroPreviousY = hero.position.y;
    console.log("Window resized");
    // Remove canvas and recreate it with new values because
    // resizeCanvas() doesn't work for some reason
    canvas.remove()
    cnv = new Canvas(resizedWindowWidth, resizedWindowHeight, 'pixelated x5');
    allSprites.pixelPerfect = true;
    // Reposition sprite 'hero' to center of new view
    if (!hero.cameraFollowX && !hero.cameraFollowY)
    {
        hero.position.x = resizedWindowWidth / SPRITEWIDTHOFFSET;
    }
    else if (hero.cameraFollowX && hero.cameraFollowY)
    {
        hero.position.x = heroPreviousX;
        hero.position.y = heroPreviousY;
    }
}

// Function to remove an html element
function removeElement(idToRemove) {
    let element = document.getElementById(idToRemove);
    return element.parentNode.removeChild(element);
}

// Function to check whether a name has been inputted into the input box
function nameInputted() {
    let nameInput = document.getElementById("nameInput").value;
    if (nameInput === "" || nameInput === " " || nameInput === '' || nameInput === ' ' || nameInput === null) 
    {
        return false;
    }
    else if (nameInput.length > 0)
    {
        if (nameIsValid(nameInput))
        {
            nameHasBeenInputted = true;
            return true;
        }
        else
        {
            return false;
        }
    }
}

// Function to check whether the inputted name contains only letters
function nameIsValid(name) {
    // Credit: geeksforgeeks.org for the regex code
    let letterTest = /^[a-zA-Z]+$/;
    if (letterTest.test(name))
    {
        return true;
    }
    else if (!letterTest.test(name))
    {
        return false;
    }
}

function draw() {
	clear();
	background(bgImage);
	if (hero.cameraFollowY)
	{
    	camera.y = hero.y - CAMSPRITEYOFFSET;
	}
	if (hero.cameraFollowX)
	{
	    camera.x = hero.x;
	}
    if(riseAnimationPlayed)
    {
    	if(kb.pressing("ArrowLeft"))
    	{
            hero.mirror.x = true;
            hero.vel.x = -HEROSPEED;
            hero.changeAni('run');
    	}
    	if(kb.released("ArrowLeft"))
    	{
    	    hero.vel.x = 0;
    	    hero.changeAni('stand');
    	}
    	if(kb.pressing("ArrowRight"))
    	{
            hero.mirror.x = false;
            hero.vel.x = HEROSPEED;
            hero.changeAni('run');
    	}
    	if(kb.released("ArrowRight"))
    	{
    	    hero.vel.x = 0;
    	    hero.changeAni('stand');
    	}
    	if(kb.pressed("ArrowUp"))
    	{
            if(hero.vel.y === 0){
            spriteJumpAni();
            hero.vel.y = JUMPHEIGHT;
            }
    	}
    	if(hero.colliding(level1Tiles) == true)
    	{
    	    //console.log(hero.colliding(floor));
    	    hero.changeAni('stand');
    	    hero.isJumping = false;
    	}
    	if(hero.overlap(cameraDisable) == true){
    	    hero.cameraFollowX = false;
    	}
    	if(hero.overlap(leftWallCheck) == true)
    	{
    	    hero.cameraFollowX = true;
    	}

    }
}

function spriteJumpAni() {
    hero.changeAni('jump');
}
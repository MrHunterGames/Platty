/******************
 * Main js file for platformer game
 * Created by Hunter Chapman
 * Level 2 Programming assesment
 ******************/

// Constants
const SPRITEYOFFSET = 12; // Offset for the hero sprite from the bottom of the screen
const CAMSPRITEYOFFSET = 3; // Y Offset for the camera
const SPRITEWIDTHOFFSET = 2; // The width offset for the sprite on the start screen
const WINDOWHEIGHTOFFSET = 360; // The height offset for the start screen so the header doesn't cause scrolling
const SCALEFACTOR = 5; // The view scale factor of the whole game/canvas
const HEROFRAMEDELAY = 8; // Hero animation frame delay (x-axis)
const JUMPHEIGHT = 35; // Jump height of the hero sprite
const HEROSPEED = 2.5; // X-Axis velocity of the movement of the hero sprite
const TILEXOFFSET = 400; // X-Axis offset for the spawning of the Tiles
const PIXELSCALE = "pixelated x5"; // A constant for the pixel scale of the canvas to avoid having to manually change it
const HEALTHREGENERATIONINTERVAL = 60; // How many milliseconds before each health regen check
const HEALTHREGENERATIONAMOUNT = 10; // Amount of health to regen per check
const WALLRUNJUMPHEIGHT = 80; // Jump height for the hero when running on walls as the physics operate differently then
const HEALTHUIOFFSET = 18; // The division offset for the Health UI

// Predefines
let hero; // Hero Sprite
let spriteSheetHero;
let bgImage;
let plattyBackground;
let nameHasBeenInputted = false;
let riseAnimationPlayed = false;
let propTiles;
let groundTiles;
let swampTiles;
let airTile;
let lavaTile;
let damageTaken = 0;
let deathMessagePlayed = false;
let nameInput;
let audioEnabled;
let lavaHitLow;
let lavaHitHigh;
let backgroundMusic;
let altTiles;
let settingsOpen = false;
let floatingDirtLeft;
let floatingDirtRight;
let floatingDirtSolo;
let finishFlag;
let tutorialOpen = false;
let finishMessageOpen = false;
let time = 0;
let timerHasStarted = false;
let timerInterval;
let currentLevel;
let boar;
let boarSheet;
let boarsSpawned = 0;
let boars = [];
let healthQuarterDown;
let fullHealth;
let halfHealth;
let quarterHealthLeft;
let noHealthLeft;
let healthLowerBound;
let healthUpperBound;
let healthVariable;
let healthRegenerationTimer = 0;
let healthRestoring = false;
let boarSpeed;
let floatingDirtMiddle;
let antiGravityGrassTile;
let antiGravity = false;
let heroWalking = false;
let gravityPortal;
let wallGravityPortal;
let wallRunGrass;
let wallRunning = false;
let gravityIsNormal = true;
let totalTime = 0;
let totalTimerHasStarted = false;
let totalTimeVariable;

/* Preload function, currently just loading images,
 * tilesheets, spritesheets, etc */
function preload() {
    spriteSheetHero = loadImage("/resources/questKid.png");
    bgImage = loadImage("/resources/loginPageBackground.jpeg");
    plattyBackground = loadImage("/resources/gameBackground.png");
    swampTiles = loadImage("/resources/tilesets/swampTiles.png");
    groundTiles = loadImage("/resources/tilesets/groundTiles.png");
    propTiles = loadImage("/resources/tilesets/propTiles.png");
    airTile = loadImage("/resources/tilesets/air.png");
    lavaTile = loadImage("resources/tilesets/lava.png");
    altTiles = loadImage("/resources/tilesets/groundTiles.png");
    lavaHitLow = loadSound("https://codehs.com/uploads/3dfdda4b3e49065129b8840c7628d9ca");
    lavaHitHigh = loadSound("https://codehs.com/uploads/e9521e85ad516909f5f6c0993dac8c40");
    lavaHitNorm = loadSound("https://codehs.com/uploads/1def79641167cc982cc4a1fa93379beb");
    backgroundMusic = loadSound("https://codehs.com/uploads/b7bc2716f9b557de6ecd6f9ddf48944a");
    floatingDirtRight = loadImage("/resources/tilesets/floatingDirtRight.png");
    floatingDirtLeft = loadImage("/resources/tilesets/floatingDirtLeft.png");
    floatingDirtSolo = loadImage("/resources/tilesets/floatingDirtSolo.png");
    floatingDirtMiddle = loadImage("/resources/tilesets/floatingDirtMiddle.png");
    antiGravityGrassTile = loadImage("/resources/tilesets/antiGravityGrass.png");
    finishFlag = loadImage("/resources/tilesets/finishFlag.png");
    boarSheet = loadImage("/resources/tilesets/boar.png");
    healthQuarterDown = loadImage("/resources/tilesets/healthQuarterDown.png");
    halfHealth = loadImage("/resources/tilesets/halfHealth.png");
    fullHealth = loadImage("/resources/tilesets/fullHealth.png");
    quarterHealthLeft = loadImage("/resources/tilesets/quarterHealth.png");
    noHealthLeft = loadImage("/resources/tilesets/emptyHealth.png");
    healthLowerBound = loadImage("/resources/tilesets/healthLowerBound.png");
    healthUpperBound = loadImage("/resources/tilesets/healthUpperBound.png");
    gravityPortal = loadImage("/resources/tilesets/gravityPortal.png");
    wallGravityPortal = loadImage("/resources/tilesets/wallGravityPortal.png");
    wallRunGrass = loadImage("/resources/tilesets/wallRunGrass.png");
}

// Setup function, creates canvas, sprites, and assigns animations
function setup() {
    // Get window height before it is upscaled by the PIXELSCALE in create canvas
    let unalteredWindowHeight = (windowHeight - WINDOWHEIGHTOFFSET) / SCALEFACTOR;
    let unalteredWindowWidth = windowWidth / SCALEFACTOR;

    // Create canvas
    cnv = new Canvas(unalteredWindowWidth, unalteredWindowHeight, PIXELSCALE);
    allSprites.pixelPerfect = true;
    console.log("Canvas is (width/height): " + canvas.w + "/" + canvas.h);

    // Create sprite
    hero = new Sprite(
        unalteredWindowWidth / SPRITEWIDTHOFFSET,
        unalteredWindowHeight - SPRITEYOFFSET,
        32,
        32,
        "k",
    );
    console.log("Hero's (sprite) X/Y coordinates are: " + hero.x + "/" + hero.y);
    hero.rotationLock = true;
    hero.spriteSheet = spriteSheetHero;
    hero.anis.offset.x = SPRITEWIDTHOFFSET;
    hero.anis.offset.y = -5;
    hero.anis.frameDelay = HEROFRAMEDELAY;
    world.gravity.y = 10;
    world.gravity.x = 0;

    // Create sprite animation and assign sleeping ani to sprite
    hero.addAnis({
        run: {
            row: 0,
            frames: 8,
        },
        jump: {
            row: 1,
            frames: 6,
        },
        roll: {
            row: 2,
            frames: 5,
            frameDelay: 14,
        },
        turn: {
            row: 3,
            frames: 7,
        },
        stand: {
            row: 3,
            frames: 1,
        },
        sleeping: {
            row: 21,
            frames: 10,
        },
        riseFromGround: {
            row: 23,
            frames: 6,
        },
        sword: {
            row: 12,
            frames: 10,
        },
    });

    //Misc changes to the sprite to ensure maximum playability
    hero.changeAni("sleeping");
    hero.w = 13;
    hero.h = 15;
    hero.friction = 0;
    allSprites.bounciness = 0.1;
    hero.wallCollisionHappened = false;
    hero.tutorialAlertHasPlayed = false;
}

// Function that adds an event listener to allow the user to start
// typing on the start page and have it automatically select the name input
// box
document.addEventListener("DOMContentLoaded", function() {
    let nameInput = document.getElementById("nameInput");

    // Focus on input when user starts typing
    document.addEventListener("keydown", function() {
        nameInput.focus();
    });

    // Remove outline when input is focused
    nameInput.addEventListener("focus", function() {
        nameInput.classList.add("noOutline");
    });

    // Add outline when input is blurred
    nameInput.addEventListener("blur", function() {
        nameInput.classList.remove("noOutline");
    });
});

// Checks whether audio has been enabled by the user
function audioCheck() {
    audioEnabled = document.getElementById("audio").checked;
    if (audioEnabled) {
        console.log("Audio has been turned on");
        if (!backgroundMusic.isPlaying()) {
            backgroundMusic.play();
        }
    } else if (!audioEnabled) {
        console.log("Audio has been turned off");
        if (backgroundMusic.isPlaying()) {
            backgroundMusic.pause();
        }
    }
}

// Game start Function, called on click of play button, resizes-
// canvas, adds background, removes html elements
function startGame() {
    let totalTimeVariable = setInterval(totalTimerStart, 1000);
    healthVariable = fullHealth;
    audioEnabled = document.getElementById("audio").checked;
    // First, check if a name has been inputted
    if (!nameInputted()) {
        document.getElementById("userNameHint").textContent =
            "Please enter a name containing only letters";
    } else if (nameInputted()) {
        // Removes Header and play button elements, they're being-
        // removed instead of hidden as when theyre hidden the canvas-
        // can't use the full screen size without scrolling otherwise
        removeElement("htmlElements");

        //Create new variables with accurate window width/height
        let resizedWindowHeight = windowHeight / SCALEFACTOR;
        let resizedWindowWidth = windowWidth / SCALEFACTOR;

        bgImage = plattyBackground;
        allSprites.pixelPerfect = true;
        console.log("Canvas has been resized, game started");
        // Calls the function that creates the tiles
        startLevel1();
        // Remove canvas and recreate it with new values because
        // resizeCanvas() doesn't work for some reason
        canvas.remove();
        cnv = new Canvas(resizedWindowWidth, resizedWindowHeight, PIXELSCALE);
        hero.cameraFollowY = true;
        hero.cameraFollowX = true;
        hero.collider = "dynamic";
    }
}

// Function called that initiates the spawnMob process, is scaleable as it can
// be dictated the amount to spawn based on the amount of spawn point tiles present
function spawnMobs(type, tileset, speed, startDir) {
    if (type === "boar" || type === "gravityBoar") {
        boarSpeed = speed;
        boarWalkingLeft = startDir === "left";
        let boarSpawnPoints = findTile(
            tileset,
            type === "boar" ? "boar" : "gravityBoar",
        );
        for (let i = 0; i < boarSpawnPoints.length; i++) {
            initiateSpawn(
                type,
                boarSpawnPoints[i].x,
                boarSpawnPoints[i].y,
                1,
                speed,
                startDir,
            );
        }
    } else if (type === "player") {
        let playerSpawnPoint = findTile(tileset, "player");
        for (let i = 0; i < playerSpawnPoint.length; i++) {
            hero.position.x = playerSpawnPoint[i].x;
            hero.position.y = playerSpawnPoint[i].y;
            hero.changeAni("riseFromGround");
            hero.animation.looping = false;
            riseAnimationPlayed = true;
        }
    }
}

// Once the correct position, etc has been found by spawnMobs() this gets fed 
// that data and creates an array for the mobs, then sends that off to createBoar()
function initiateSpawn(type, x, y, amount, speed, startDir) {
    for (let i = 0; i < amount; i++) {
        if (type === "boar") {
            let newBoar = createBoar(x, y, speed, startDir, "normal"); // Function to create a new boar
            boars.push(newBoar); // Add the new boar to the array
        } else if (type === "gravityBoar") {
            let newBoar = createBoar(x, y, speed, startDir, "gravity"); // Function to create a new boar
            boars.push(newBoar); // Add the new boar to the array
        }
    }
}


// Creates the boar with the data given
function createBoar(x, y, speed, startDir, type) {
    if (type === "normal") {
        let newBoar = createSprite(x, y - 8, 48, 32, "k"); // Create a new boar sprite
        if (startDir === "left") {
            newBoar.velocity.x = -speed;
        } else {
            newBoar.velocity.x = speed;
        }
        newBoar.spriteSheet = boarSheet;
        newBoar.addAnis({
            walk: {
                frames: 6,
            },
        });
        newBoar.rotationLock = true;
        newBoar.w = 40;
        newBoar.h = 20;
        console.log("Boar spawned");
        boarsSpawned++;
        return newBoar;
    } else if (type === "gravity") {
        let newBoar = createSprite(x, y - 8, 48, 32, "k"); // Create a new boar sprite
        if (startDir === "left") {
            newBoar.velocity.x = -speed;
        } else {
            newBoar.velocity.x = speed;
        }
        newBoar.spriteSheet = boarSheet;
        newBoar.addAnis({
            walk: {
                frames: 6,
            },
        });
        newBoar.rotationLock = true;
        newBoar.w = 40;
        newBoar.h = 20;
        newBoar.rotateTo(180, 20);
        newBoar.antiGravity = true;
        console.log("Boar spawned");
        boarsSpawned++;
        return newBoar;
    }
}

// Function to remove mobs from both their array and their sprites
function removeMob(type) {
    if (type === "boar" || type === "gravityBoar") {
        if (boars.length > 0) {
            for (let i = boars.length - 1; i >= 0; i--) {
                let removedBoar = boars.splice(i, 1)[0]; // Remove the first boar from the array
                removedBoar.remove(); // Remove the sprite from the canvas
                console.log("Boar removed");
            }
        }
    } else if (type === "player") {
        if (playerSpawnPoint.length > 0) {
            playerSpawnPoint.length = 0;
        }
    }
}

// Function that iterates through every tile to find the spawn point tiles based
// on their indicator, then adds it to an array
function findTile(tileset, type) {
    if (type === "boar") {
        let boarSpawnPoints = [];
        for (let i = 0; i < tileset.length; i++) {
            if (tileset[i].tile === "B") {
                // Check if the tile type is 'B' (boar)
                boarSpawnPoints.push({
                    // Add the spawn point to the array
                    x: tileset[i].x,
                    y: tileset[i].y,
                });
            }
        }
        return boarSpawnPoints;
    }
    if (type === "player") {
        let playerSpawn = [];
        for (let i = 0; i < tileset.length; i++) {
            if (tileset[i].tile === "P") {
                playerSpawn.push({
                    x: tileset[i].x,
                    y: tileset[i].y,
                });
            }
        }
        return playerSpawn;
    }
    if (type === "gravityBoar") {
        let boarSpawnPoints = [];
        for (let i = 0; i < tileset.length; i++) {
            if (tileset[i].tile === "N") {
                // Check if the tile type is 'N' (gravity boar)
                boarSpawnPoints.push({
                    // Add the spawn point to the array
                    x: tileset[i].x,
                    y: tileset[i].y,
                });
            }
        }
        return boarSpawnPoints;
    }
}

// Initialises level 1 & all tiles to be used throughout the game
function startLevel1() {
    currentLevel = 1;
    levelStartDialogue();
    //Create new variables with accurate window width/height
    let resizedWindowHeight = windowHeight / SCALEFACTOR;
    let resizedWindowWidth = windowWidth / SCALEFACTOR;
    let xCoord = hero.position.x - TILEXOFFSET;
    let yCoord = resizedWindowHeight - 15;
    console.log("creating tiles for first level");
    swampGrass = new Group();
    swampGrass.tile = "s";
    swampGrass.collider = "static";
    swampGrass.spriteSheet = swampTiles;
    swampGrass.addAni({
        w: 16,
        h: 16,
        row: 0,
        col: 1,
    });

    swampDirt = new Group();
    swampDirt.tile = "d";
    swampDirt.collider = "static";
    swampDirt.spriteSheet = swampTiles;
    swampDirt.addAni({
        w: 16,
        h: 16,
        row: 1,
        col: 1,
    });

    grassLeftCorner = new Group();
    grassLeftCorner.tile = "l";
    grassLeftCorner.collider = "static";
    grassLeftCorner.spriteSheet = swampTiles;
    grassLeftCorner.addAni({
        w: 16,
        h: 16,
        row: 0,
        col: 5,
    });

    grassBottomLeftCorner = new Group();
    grassBottomLeftCorner.tile = "L";
    grassBottomLeftCorner.collider = "static";
    grassBottomLeftCorner.spriteSheet = swampTiles;
    grassBottomLeftCorner.addAni({
        w: 16,
        h: 16,
        row: 4,
        col: 7,
    });

    grassRightCorner = new Group();
    grassRightCorner.tile = "r";
    grassRightCorner.collider = "static";
    grassRightCorner.spriteSheet = swampTiles;
    grassRightCorner.addAni({
        w: 16,
        h: 16,
        row: 0,
        col: 0,
    });

    grassBottomRightCorner = new Group();
    grassBottomRightCorner.tile = "R";
    grassBottomRightCorner.collider = "static";
    grassBottomRightCorner.spriteSheet = swampTiles;
    grassBottomRightCorner.addAni({
        w: 16,
        h: 16,
        row: 4,
        col: 10,
    });

    leftWallCheck = new Group();
    leftWallCheck.tile = "a";
    leftWallCheck.collider = "none";
    leftWallCheck.image = airTile;
    leftWallCheck.w = 16;
    leftWallCheck.h = 16;

    cameraDisable = new Group();
    cameraDisable.tile = "k";
    cameraDisable.collider = "none";
    cameraDisable.image = airTile;
    cameraDisable.w = 16;
    cameraDisable.h = 16;

    air = new Group();
    air.tile = "A";
    air.collider = "static";
    air.image = airTile;
    air.w = 26;
    air.h = 16;

    lava = new Group();
    lava.tile = "m";
    lava.collider = "none";
    lavaTile.resize(16, 16);
    lava.image = lavaTile;
    lavaHitNorm.audioCount = 0;
    lavaHitHigh.audioCount = 0;
    lavaHitLow.audioCount = 0;

    floatGrassLeft = new Group();
    floatGrassLeft.tile = "f";
    floatGrassLeft.collider = "static";
    floatingDirtLeft.resize(16, 16);
    floatGrassLeft.image = floatingDirtLeft;

    floatGrassMiddle = new Group();
    floatGrassMiddle.tile = "M";
    floatGrassMiddle.collider = "static";
    floatingDirtMiddle.resize(16, 16);
    floatGrassMiddle.image = floatingDirtMiddle;

    floatGrassRight = new Group();
    floatGrassRight.tile = "F";
    floatGrassRight.collider = "static";
    floatingDirtRight.resize(16, 16);
    floatGrassRight.image = floatingDirtRight;

    floatGrassSolo = new Group();
    floatGrassSolo.tile = "D";
    floatGrassSolo.collider = "static";
    floatingDirtSolo.resize(16, 16);
    floatGrassSolo.image = floatingDirtSolo;

    antiGravityGrass = new Group();
    antiGravityGrass.tile = "U";
    antiGravityGrass.collider = "static";
    antiGravityGrassTile.resize(16, 16);
    antiGravityGrass.image = antiGravityGrassTile;

    wallRunningGrass = new Group();
    wallRunningGrass.tile = "w";
    wallRunningGrass.collider = "static";
    wallRunGrass.resize(16, 16);
    wallRunningGrass.image = wallRunGrass;

    finishFlagTile = new Group();
    finishFlagTile.tile = "T";
    finishFlag.resize(40, 35);
    finishFlagTile.collider = "none";
    finishFlagTile.image = finishFlag;
    finishFlagTile.w = 16;
    finishFlagTile.h = 16;

    boarSpawnTile = new Group();
    boarSpawnTile.tile = "B";
    boarSpawnTile.collider = "none";
    boarSpawnTile.image = airTile;
    boarSpawnTile.w = 16;
    boarSpawnTile.h = 16;

    gboarSpawnTile = new Group();
    gboarSpawnTile.tile = "N";
    gboarSpawnTile.collider = "none";
    gboarSpawnTile.image = airTile;
    gboarSpawnTile.w = 16;
    gboarSpawnTile.h = 16;

    boarBoundLeft = new Group();
    boarBoundLeft.tile = "b";
    boarBoundLeft.collider = "none";
    boarBoundLeft.image = airTile;
    boarBoundLeft.w = 16;
    boarBoundLeft.h = 16;

    boarBoundRight = new Group();
    boarBoundRight.tile = "n";
    boarBoundRight.collider = "none";
    boarBoundRight.image = airTile;
    boarBoundRight.w = 16;
    boarBoundRight.h = 16;

    playerSpawnPoint = new Group();
    playerSpawnPoint.tile = "P";
    playerSpawnPoint.collider = "none";
    playerSpawnPoint.image = airTile;
    playerSpawnPoint.w = 16;
    playerSpawnPoint.h = 16;

    antiGravityBlock = new Group();
    antiGravityBlock.tile = "g";
    antiGravityBlock.collider = "none";
    gravityPortal.resize(32, 32);
    antiGravityBlock.image = gravityPortal;
    antiGravityBlock.w = 16;
    antiGravityBlock.h = 16;

    wallRunBlock = new Group();
    wallRunBlock.tile = "W";
    wallRunBlock.collider = "none";
    wallGravityPortal.resize(16, 16);
    wallRunBlock.image = wallGravityPortal;
    wallRunBlock.w = 16;
    wallRunBlock.h = 16;

    level1Tiles = new Tiles(
        [
            ".......A........ka............................................................................ak........A...",
            ".......A........ka.......................................................................A....ak........A...",
            ".......A........ka.....................................................................T.A....ak........A...",
            ".......A........ka....................................................................fFM.....ak........A...",
            ".......A........ka..............................................................D.............ak........A...",
            ".......A........ka........................................................fF..................ak........A...",
            ".......A........ka.................................................D..........................ak........A...",
            ".......A........ka..........................................fF................................ak........A...",
            ".......A........ka...................................fF.......................................ak........A...",
            ".......A........ka..................P...............................b...B...n.................ak........A...",
            "ssssssssssssssssssssssssssssssssssssssssslmmrsssssslmmmrssssslmmmmmrssssssssslmmmrssssssssssssssssssssssssss",
            "dddddddddddddddddddddddddddddddddddddddddLssRddddddLsssRdddddLsssssRdddddddddLsssRdddddddddddddddddddddddddd",
            "dddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddd",
            "dddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddd",
            "dddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddd",
            "dddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddd",
            "dddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddd",
            "dddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddd",
            "dddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddd",
        ],
        xCoord,
        yCoord,
        16,
        16,
    );
    spawnMobs("player", level1Tiles);
    spawnMobs("boar", level1Tiles, 0.5, "left");
    finishFlagTile[0].mirror.x = true;
}

// Starts level 2
function startLevel2() {
    currentLevel = 2;
    levelStartDialogue();
    //Create new variables with accurate window width/height
    let resizedWindowHeight = windowHeight / SCALEFACTOR;
    let resizedWindowWidth = windowWidth / SCALEFACTOR;
    hero.collider = "dynamic";
    let xCoord = hero.position.x - TILEXOFFSET;
    let yCoord = resizedWindowHeight - 15;

    canvas.remove();
    cnv = new Canvas(resizedWindowWidth, resizedWindowHeight, PIXELSCALE);

    console.log("creating tiles for second level");

    level2Tiles = new Tiles(
        [
            ".......A........ka............................................................................ak........A...",
            ".......A........ka.........................................................UUUUU..............ak........A...",
            ".......A........ka.............................................................g..............ak........A...",
            ".......A........ka.....................................................................A......ak........A...",
            ".......A........ka.....................................................................A......ak........A...",
            ".......A........ka...............................................UUUUUU...............TA......ak........A...",
            ".......A........ka.............................................................fMfMfMfFM.......ak........A...",
            ".......A........ka............................................................................ak........A...",
            ".......A........ka............................................................................ak........A...",
            ".......A........ka................................................g...........................ak........A...",
            ".......A........ka................................b....B..n....DDD............................ak........A...",
            ".......A........ka............................D...fMfMfMfMF...................................ak........A...",
            ".......A........ka.................P..........................................................ak........A...",
            "ssssssssssssssssssssssssssssssssssssssssslmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmrssssssssssssssssssss",
            "dddddddddddddddddddddddddddddddddddddddddLsssssssssssssssssssssssssssssssssssssssssssssRdddddddddddddddddddd",
            "dddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddd",
            "dddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddd",
            "dddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddd",
            "dddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddd",
            "dddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddd",
            "dddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddd",
            "dddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddd",
        ],
        xCoord,
        yCoord,
        16,
        16,
    );
    spawnMobs("player", level2Tiles);
    spawnMobs("boar", level2Tiles, 0.5, "left");
}

// Starts level 3
function startLevel3() {
    currentLevel = 3;
    levelStartDialogue();
    //Create new variables with accurate window width/height
    let resizedWindowHeight = windowHeight / SCALEFACTOR;
    let resizedWindowWidth = windowWidth / SCALEFACTOR;
    let xCoord = hero.position.x - TILEXOFFSET;
    let yCoord = resizedWindowHeight - 15;

    canvas.remove();
    cnv = new Canvas(resizedWindowWidth, resizedWindowHeight, PIXELSCALE);

    console.log("creating tiles for third level");

    level3Tiles = new Tiles(
        [
            ".......A........ka................................................UUUUUUUUUUUUUUU.............ak........A...",
            ".......A........ka............................................................................ak........A...",
            ".......A........ka.................................................b.....N...n...g............ak........A...",
            ".......A........ka............................................................................ak........A...",
            ".......A........ka............................................................................ak........A...",
            ".......A........ka............................................................................ak........A...",
            ".......A........ka............................................................................ak........A...",
            ".......A........ka.......................UUUUUUUUUUUUU........................................ak........A...",
            ".......A........ka...................................g....UUUUUUU........................A....ak........A...",
            ".......A........ka.....................................................................T.A....ak........A...",
            ".......A........ka...............................................................fMfMfMFM.....ak........A...",
            ".......A........ka............................................................................ak........A...",
            ".......A........ka................b.P..Bng....................................................ak........A...",
            ".......A........ka................fMfMfMfM................g...................................ak........A...",
            ".......A........ka...................................fMfM.....................................ak........A...",
            ".......A........ka............................................................................ak........A...",
            "sssssssssssssssslmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmrsssssssssssss",
            "ddddddddddddddddLsssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssRddddddddddddd",
            "dddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddd",
            "dddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddd",
            "dddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddd",
            "dddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddd",
            "dddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddd",
            "dddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddd",
            "dddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddd",
        ],
        xCoord,
        yCoord,
        16,
        16,
    );
    spawnMobs("player", level3Tiles);
    spawnMobs("gravityBoar", level3Tiles, 1, "left");
}

// Starts level 4
function startLevel4() {
    currentLevel = 4;
    levelStartDialogue();
    //Create new variables with accurate window width/height
    let resizedWindowHeight = windowHeight / SCALEFACTOR;
    let resizedWindowWidth = windowWidth / SCALEFACTOR;
    let xCoord = hero.position.x - TILEXOFFSET;
    let yCoord = resizedWindowHeight - 15;

    canvas.remove();
    cnv = new Canvas(resizedWindowWidth, resizedWindowHeight, PIXELSCALE);

    console.log("creating tiles for third level");

    level4Tiles = new Tiles(
        [
            ".......A........ka....................................................................................................ak........A...",
            ".......A........ka....................................................................................................ak........A...",
            ".......A........ka...........................................................................UUUUUw...................ak........A...",
            ".......A........ka..........................................................UUUUUUUUU.............w...................ak........A...",
            ".......A........ka..................................................................g........W....w......UUUUU........ak........A...",
            ".......A........ka.....................................................................b.B...n....w..........g.....A..ak........A...",
            ".......A........ka..................................................................fMfMfMfMfM....w...............TA..ak........A...",
            ".......A........ka.......................UUUUUUUUU................................................w..........fMfMFM...ak........A...",
            ".......A........ka..........................W....w........UUUUUUUUUUUUUUUU........................w...................ak........A...",
            ".......A........ka...............................w..........b....N....n...........................w...................ak........A...",
            ".......A........ka...............................w................................................w...................ak........A...",
            ".......A........ka...............................w................................................w........gw.........ak........A...",
            ".......A........ka..................P....g......Ww................................................w.........w.........ak........A...",
            ".......A........ka................fMfMfMfM................g.................................................w.........ak........A...",
            ".......A........ka..........................................................................................w.........ak........A...",
            ".......A........ka............................FFFFFFFFFFF...................................................w.........ak........A...",
            "sssssssssssssssslmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmwmmmmmmmmmrsssssssssssss",
            "ddddddddddddddddLsssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssRddddddddddddd",
            "dddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddd",
            "dddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddd",
            "dddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddd",
            "dddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddd",
            "dddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddd",
            "dddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddd",
            "dddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddd",
        ],
        xCoord,
        yCoord,
        16,
        16,
    );
    spawnMobs("player", level4Tiles);
    spawnMobs("boar", level4Tiles, 0.5, "left");
}

// Starts level 5
function startLevel5() {
    currentLevel = 5;
    levelStartDialogue();
    //Create new variables with accurate window width/height
    let resizedWindowHeight = windowHeight / SCALEFACTOR;
    let resizedWindowWidth = windowWidth / SCALEFACTOR;
    let xCoord = hero.position.x - TILEXOFFSET;
    let yCoord = resizedWindowHeight - 15;

    canvas.remove();
    cnv = new Canvas(resizedWindowWidth, resizedWindowHeight, PIXELSCALE);

    console.log("creating tiles for third level");

    level5Tiles = new Tiles(
        [
            ".......A........ka...............................UUUUUUUUUUU........UUUUUUUUUUU.....................UUUw..............ak........A...",
            ".......A........ka.........................................g.................g.........................w..............ak........A...",
            ".......A........ka.................................b..N.n..............................................w..............ak........A...",
            ".......A........ka.................................................g........fMfMfM...............W.....w..............ak........A...",
            ".......A........ka...............................gw.........fMfMfMfM.................D.................w..UUUUUUU.....ak........A...",
            ".......A........ka................................w......................................fMfMfMfM......w.......g......ak........A...",
            ".......A........ka....................UUU.........w....................................................w............A.ak........A...",
            ".......A........ka......UUUUw............g........w....................................................w...........TA.ak........A...",
            ".......A........ka........W.w.....................w...................................................Ww.......fMfMF..ak........A...",
            ".......A........ka..........w..............W......w...................................................................ak........A...",
            ".......A........ka..........wUUUUU.......fF.......w...................................................................ak........A...",
            ".......A........ka...............w..............fFM.......................................................g...........ak........A...",
            ".......A........ka...P..g........w...................................................................fMfMfM...........ak........A...",
            ".......A........ka...D..........Ww....................................................................................ak........A...",
            ".......A........ka....................g...............................................................................ak........A...",
            ".......A........ka....................................................................................................ak........A...",
            ".......A........ka.............b...B..n...............................................................................ak........A...",
            ".......A........ka.............fMfMfMfM...............................................................................ak........A...",
            "sssssssssssssssslmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmrsssssssssssss",
            "ddddddddddddddddLsssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssRddddddddddddd",
            "dddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddd",
            "dddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddd",
            "dddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddd",
            "dddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddd",
            "dddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddd",
            "dddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddd",
            "dddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddd",
        ],
        xCoord,
        yCoord,
        16,
        16,
    );
    spawnMobs("player", level5Tiles);
    spawnMobs("boar", level5Tiles, 2, "left");
    spawnMobs("gravityBoar", level5Tiles, 2, "left");
}

// Function that utilises jQuery to bring a pop up dialogue to the screen
// credit to ChatGPT for the base of the jQuery function as i wouldn't have
// even known where to start otherwise
// Note: Dialog is spelled without the -ue as it seems to break jQuery when spelt with
function settingsDialog() {
    settingsOpen = true;
    // Create a div element to hold the dialog content
    let dialogContent =
        '<div id="dialog" title="Settings">' +
        '<input style="margin: 0; auto"type="checkbox" id="musicEnabled">' +
        '<label for="musicEnabled">  Music enabled</label>' +
        "</div>";

    // Append the dialog content to the body
    $("body").append(dialogContent);

    // Change the value of the checkbox on open to checked/unchecked
    // dependent on the value of the audioEnabled variable (bool)
    $("#musicEnabled").prop("checked", audioEnabled);

    // Bind a function to the checkbox's change event to update audioEnabled
    $("#musicEnabled").change(function() {
        audioEnabled = this.checked;
        console.log("Music enabled: " + audioEnabled);
    });

    // Initialize the dialog
    $("#dialog").dialog({
        autoOpen: true,
        modal: true,
        buttons: [], // Empty buttons to remove "Save" button

        close: function() {
            settingsOpen = false;
            $(this).dialog("destroy").remove(); // Remove dialog from DOM after closing
        },
    });
    $("<button>").appendTo("#dialog").focus().remove();
}

// Function that starts a timer when it's called in a setInterval
function timerStart() {
    if (!timerHasStarted) {
        console.log("Timer Started!");
        timerHasStarted = true;
    }
    time++;
}

// Same as above, except for total time of the whole game rather than per level
function totalTimerStart() {
    if (!totalTimerHasStarted) {
        console.log("Timer Started!");
        totalTimerHasStarted = true;
    }
    totalTime++;
}

// Function that stops the timer
function timerStop() {
    clearInterval(timerInterval);
    timerHasStarted = false;
}

// Another jQuery UI dialogue box, this creates the pop up at the start of each level
// no ChatGPT used either this time
function levelStartDialogue() {
    tutorialOpen = true;
    let dialogID = "dialogNo" + currentLevel;
    if (currentLevel === 1) {
        let tutorialDialogue =
            '<div id="' +
            dialogID +
            '" title="Level 1">' +
            '<h1 style="text-align: center">Level 1</h1>' +
            '<p style="text-align: center; font-size: 15px; font-family: Copperplate,Copperplate Gothic Light,fantasy;">Welcome to the first level ' +
            nameInput +
            "! Use the arrow keys to move around and jump, and avoid the lava, it won't kill you immediately, but it'll hurt, and be careful of the boars, they bite!<br>When you get to the flag at the end of the level, walk (or jump) into it to complete the level!<br>If you turn red, you're taking damage, if you turn green, you're healing, you can keep track of where you're at with the handy health bar in the top left!<br>Keep an eye out at the end too for the secret prize!<br>P.S. You should play this in full screen for the best experience, and if you get stuck, press 'R' on your keyboard to restart the level!</p>" +
            "</div>";
        $("body").append(tutorialDialogue);
    } else if (currentLevel === 2) {
        let level2Dialogue =
            '<div id="' +
            dialogID +
            '" title="Level 2">' +
            '<h1 style="text-align: center; font-family: Copperplate,Copperplate Gothic Light,fantasy;">Level 2</h1>' +
            '<p style="text-align: center">Congratulations, ' +
            nameInput +
            ", you made it past the first level!<br> Things are somewhat similar here to the previous level, except for the purple portals, if you see one of these, walk into it, and gravity will reverse!</p>" +
            "</div>";
        $("body").append(level2Dialogue);
    } else if (currentLevel === 3) {
        let level3Dialogue =
            '<div id="' +
            dialogID +
            '" title="Level 3">' +
            '<h1 style="text-align: center; font-family: Copperplate,Copperplate Gothic Light,fantasy;">Level 3</h1>' +
            '<p style="text-align: center">Congratulations, ' +
            nameInput +
            ", you made it past the second level! <br>You're not going to see any new mechanics around here (apart from the gravity boars, you'll see what i mean), this level is simply like the previous one if it was on steroids! <br>Careful, theres a boar coming your way!</p>" +
            "</div>";
        $("body").append(level3Dialogue);
    } else if (currentLevel === 4) {
        let level4Dialogue =
            '<div id="' +
            dialogID +
            '" title="Level 4">' +
            '<h1 style="text-align: center">Level 4</h1>' +
            '<p style="text-align: center">Congratulations, ' +
            nameInput +
            ", you made it past the third level!<br> Things are a bit different here, you'll notice some new blue portals scattered around, jump into one of them and you'll gain the ability to walk (or run) on walls! So, Purple = Anti gravity, Blue = Spider monkey mode, Boars = Ouch!</p>" +
            "</div>";
        $("body").append(level4Dialogue);
    } else if (currentLevel === 5) {
        let level5Dialogue =
            '<div id="' +
            dialogID +
            '" title="Level 5">' +
            '<h1 style="text-align: center">Level 5</h1>' +
            '<p style="text-align: center">Congratulations, ' +
            nameInput +
            ", you've made it to the final level!<br> if you thought the previous two levels were difficult well then do i have a surprise, imagine the last two levels, on steroids AND crack-cocaine, thats what you're facing, good luck!</p>" +
            "</div>";
        $("body").append(level5Dialogue);
    }
    // Initialize the dialog
    $("#" + dialogID).dialog({
        autoOpen: true,
        modal: true,
        buttons: {
            Ok: function() {
                $(this).dialog("close");
            },
        },
        close: function() {
            time = 0;
            timerInterval = setInterval(timerStart, 1000);
            if (currentLevel === 3) {
                spawnMobs("boar", level3Tiles, 0.5, "left");
            }
            $(this).dialog("destroy").remove(); // Remove dialog from DOM after closing
            tutorialOpen = false;
        },
    });
    console.log("Dialogue opened");
}

// Level finished dialogue (Still jQuery)
function finishedDialogue() {
    finishMessageOpen = true;
    let dialogID = "dialogNo" + currentLevel;
    if (
        !(
            currentLevel === 5 ||
            currentLevel === 6 ||
            currentLevel === 7 ||
            currentLevel === 8 ||
            currentLevel === 9
        )
    ) {
        let finishedDialogue =
            '<div id="' +
            dialogID +
            '" title="Level ' +
            currentLevel +
            ' Completed">' +
            '<h1 style="text-align: center">Level ' +
            currentLevel +
            " Completed!</h1>" +
            '<p style="text-align: center">Congratulations ' +
            nameInput +
            "! You completed level " +
            currentLevel +
            " in " +
            time +
            " seconds!<br><br>Press Ok or close the window with the X in the top right corner to go to the next level</p>" +
            "</div>";
        $("body").append(finishedDialogue);
    } else if (currentLevel === 5) {
        let finishedDialogue =
            '<div id="' +
            dialogID +
            '" title="Game Completed!">' +
            '<h1 style="text-align: center">Game Completed!</h1>' +
            '<p style="text-align: center">Congratulations ' +
            nameInput +
            "! You finished the game! " +
            currentLevel +
            " in " +
            totalTime +
            " seconds!<br><br>Your secret prize is... Nothing!!! Didn't your parents ever tell you not to believe everything you read online?</p>" +
            "</div>";
        $("body").append(finishedDialogue);
    } else if (currentLevel === 6) {
        let finishedDialogue =
            '<div id="' +
            dialogID +
            '" title="Stop">' +
            '<h1 style="text-align: center">Stop</h1>' +
            '<p style="text-align: center">' +
            nameInput +
            ", Please stop that</p></div>";
        $("body").append(finishedDialogue);
    } else if (currentLevel === 7) {
        let finishedDialogue =
            '<div id="' +
            dialogID +
            '" title="Seriously">' +
            '<h1 style="text-align: center">Seriously</h1>' +
            '<p style="text-align: center">' +
            nameInput +
            ", stop that right now.</p></div>";
        $("body").append(finishedDialogue);
    } else if (currentLevel === 8) {
        let finishedDialogue =
            '<div id="' +
            dialogID +
            '" title="I swear to god">' +
            '<h1 style="text-align: center">I swear to god</h1>' +
            '<p style="text-align: center">' +
            nameInput +
            ", If you don't stop that right now</p></div>";
        $("body").append(finishedDialogue);
    } else if (currentLevel === 9) {
        let finishedDialogue =
            '<div id="' +
            dialogID +
            '" title="fine">' +
            '<h1 style="text-align: center">fine</h1>' +
            '<p style="text-align: center">Fine, ' +
            nameInput +
            ", you win, i give up</p></div>";
        $("body").append(finishedDialogue);
    }

    // Initialize the dialog
    $("#" + dialogID).dialog({
        autoOpen: true,
        modal: true,
        buttons: {
            Ok: function() {
                $(this).dialog("close");
            },
        },
        close: function() {
            timerStop();
            if (currentLevel === 1) {
                level1Tiles.removeAll();
                removeMob("boar");
                removeMob("player");
                startLevel2();
            } else if (currentLevel === 2) {
                level2Tiles.removeAll();
                removeMob("boar");
                removeMob("player");
                startLevel3();
            } else if (currentLevel === 3) {
                level3Tiles.removeAll();
                removeMob("boar");
                removeMob("player");
                startLevel4();
            } else if (currentLevel === 4) {
                level4Tiles.removeAll();
                removeMob("boar");
                removeMob("player");
                startLevel5();
            } else if (currentLevel === 5) { // The reason for these iterations is for the
                currentLevel = 6; // Snarky messages at the very end of the game
            } else if (currentLevel === 6) {
                currentLevel = 7;
            } else if (currentLevel === 7) {
                currentLevel = 8;
            } else if (currentLevel === 8) {
                currentLevel = 9;
            }
            $(this).dialog("destroy").remove(); // Remove dialog from DOM after closing
            finishMessageOpen = false;
        },
    });
}

// Function that's called whenever the window resizes that adjusts the location
// of the sprite, tiles, etc
function windowResized() {
    // Create new variables with accurate window width/height
    let resizedWindowHeight = windowHeight / SCALEFACTOR;
    let resizedWindowWidth = windowWidth / SCALEFACTOR;
    let heroPreviousX = hero.position.x;
    let heroPreviousY = hero.position.y;
    console.log("Window resized");
    // Remove canvas and recreate it with new values because
    // resizeCanvas() doesn't work for some reason
    canvas.remove();
    cnv = new Canvas(resizedWindowWidth, resizedWindowHeight, PIXELSCALE);
    allSprites.pixelPerfect = true;
    // Reposition sprite 'hero' to center of new view
    if (!hero.cameraFollowX && !hero.cameraFollowY) {
        hero.position.x = resizedWindowWidth / SPRITEWIDTHOFFSET;
    } else if (hero.cameraFollowX && hero.cameraFollowY) {
        hero.position.x = heroPreviousX;
        hero.position.y = heroPreviousY;
    }
}

// Function to remove an html element when called
function removeElement(idToRemove) {
    let element = document.getElementById(idToRemove);
    return element.parentNode.removeChild(element);
}

// Function to check whether a name has been inputted into the input box on call,
// and return the value true or false respective of whether a name is present
function nameInputted() {
    nameInput = document.getElementById("nameInput").value;
    if (
        nameInput === "" ||
        nameInput === " " ||
        nameInput === "" ||
        nameInput === " " ||
        nameInput === null
    ) {
        return false;
    } else if (nameInput.length > 0) {
        if (nameIsValid(nameInput)) {
            nameHasBeenInputted = true;
            return true;
        } else {
            return false;
        }
    }
}

// Function to check whether the inputted name contains only letters
// regex is funky and confusing so i don't claim this as my own code,
// credits are below.
function nameIsValid(name) {
    // Credit: geeksforgeeks.org for the regex code
    let letterTest = /^[a-zA-Z]+$/;
    if (letterTest.test(name)) {
        return true;
    } else if (!letterTest.test(name)) {
        return false;
    }
}

// Function thats called on user death, reinitialises the level
function death(tileset) {
    hero.vel.y = 0;
    hero.vel.x = 0;
    gravityIsNormal = true;
    world.gravity.y = 9.8;
    hero.cameraFollowX = true;
    hero.cameraFollowY = true;
    wallRunning = false;
    antiGravity = false;
    hero.rotateTo(0, 20);
    damageTaken = 0;
    removeMob("player");
    spawnMobs("player", tileset);
    if (!deathMessagePlayed) {
        alert(
            "Sorry " +
            nameInput +
            ", you died! Resetting you to the start of your current level.",
        );
        deathMessagePlayed = true;
    }
}

// p5play draw function, runs once every millisecond
function draw() {
    clear();
    background(bgImage);

    // Don't know how this works or what it does but it allows a static UI image and i trust
    // stackoverflow enough to know that
    push();

    // Apply camera transformation to prep for UI overlay
    translate(-camera.x, -camera.y);
    if (hero.cameraFollowY) {
        camera.y = hero.y - CAMSPRITEYOFFSET;
    }
    if (hero.cameraFollowX) {
        camera.x = hero.x;
    }
    if (riseAnimationPlayed) { // This stuff every millisecond runs when the game has started
        // Movement mechanics
        if (kb.pressing("ArrowLeft")) {
            if (tutorialOpen || settingsOpen || finishMessageOpen) {
                return;
            }
            if (!antiGravity) {
                hero.mirror.x = false;
            } else if (wallRunning) { // The reason there are so many mirror statements
                hero.mirror.x = false; // is because the mirroring seems to break otherwise
            } else if (antiGravity) { // so im not going to try fix what's not broken
                hero.mirror.x = true;
            }
            if (wallRunning) {
                hero.vel.y = -HEROSPEED;
            } else if (!wallRunning) {
                hero.vel.x = -HEROSPEED;
                if (antiGravity) {
                    hero.mirror.x = false;
                } else if (!antiGravity) {
                    hero.mirror.x = true;
                }
            }
            heroWalking = true;
            hero.changeAni("run");
        }
        if (kb.released("ArrowLeft")) {
            if (tutorialOpen || settingsOpen || finishMessageOpen) {
                return;
            }
            if (wallRunning) {
                hero.vel.y = 0;
            } else if (!wallRunning) {
                hero.vel.x = 0;
            }
            heroWalking = false;
            hero.changeAni("stand");
        }
        if (kb.pressing("ArrowRight")) {
            if (tutorialOpen || settingsOpen || finishMessageOpen) {
                return;
            }
            if (antiGravity) {
                hero.mirror.x = true;
            } else if (wallRunning) {
                hero.mirror.x = true;
            } else {
                hero.mirror.x = false;
            }
            if (wallRunning) {
                hero.vel.y = HEROSPEED;
            } else if (!wallRunning) {
                hero.vel.x = HEROSPEED;
            }
            heroWalking = true;
            hero.changeAni("run");
        }
        if (kb.released("ArrowRight")) {
            if (tutorialOpen || settingsOpen || finishMessageOpen) {}
            if (wallRunning) {
                hero.vel.y = 0;
            } else if (!wallRunning) {
                hero.vel.x = 0;
            }
            heroWalking = false;
            hero.changeAni("stand");
        }
        if (kb.pressing("ArrowUp")) {
            if (tutorialOpen || settingsOpen || finishMessageOpen) {
                return;
            }
            if (hero.vel.y === 0 && !antiGravity && !wallRunning) {
                spriteJumpAni();
                hero.vel.y = JUMPHEIGHT;
            }
            if (hero.vel.y === 0 && antiGravity) {
                spriteJumpAni();
                hero.vel.y = -JUMPHEIGHT;
            }
            if (wallRunning) {
                spriteJumpAni();
                hero.vel.x = -WALLRUNJUMPHEIGHT;
            }
        }
        if (kb.presses("r")) { // Handles the reset button ('R')
            if (
                confirm(
                    "Are you sure you want to respawn to the start of your current level?",
                )
            ) {
                if (currentLevel === 1) {
                    death(level1Tiles);
                } else if (currentLevel === 2) {
                    death(level2Tiles);
                } else if (currentLevel === 3) {
                    death(level3Tiles);
                } else if (currentLevel === 4) {
                    death(level4Tiles);
                } else if (currentLevel === 5) {
                    death(level5Tiles);
                }
            } else {
                return;
            }
        }
        // Ensures the jump animation doesn't continue to play once the user has jumped
        if (currentLevel === 1 && hero.vel.y === 0 && !heroWalking) {
            hero.changeAni("stand");
            heroJumpCount = 0;
        } else if (currentLevel === 2 && hero.vel.y === 0 && !heroWalking) {
            hero.changeAni("stand");
            heroJumpCount = 0;
        } else if (currentLevel === 3 && hero.vel.y === 0 && !heroWalking) {
            hero.changeAni("stand");
            heroJumpCount = 0;
        } else if (currentLevel === 4 && hero.vel.y === 0 && !heroWalking) {
            hero.changeAni("stand");
            heroJumpCount = 0;
        } else if (currentLevel === 5 && hero.vel.y === 0 && !heroWalking) {
            hero.changeAni("stand");
            heroJumpCount = 0;
        }
        // Handles the camera bounds at either side of the map
        if (hero.overlap(cameraDisable) == true) {
            hero.cameraFollowX = false;
        }
        if (hero.overlap(leftWallCheck) == true) {
            hero.cameraFollowX = true;
        }
        // Deals with the anti gravity and wall running, ignore the weird formatting
        // blame Prettier.io (JS formatter)
        if (
            currentLevel === 2 ||
            currentLevel === 3 ||
            currentLevel === 4 ||
            currentLevel === 5
        ) {
            if (
                hero.overlaps(antiGravityBlock) &&
                (!antiGravity || gravityIsNormal)
            ) {
                world.gravity.y = -10;
                wallRunning = false;
                gravityIsNormal = false;
                antiGravity = true;
                hero.mirror.x = true;
                hero.rotateTo(180, 20);
                console.log("No gravity");
            } else if (
                hero.overlaps(antiGravityBlock) &&
                (antiGravity || !gravityIsNormal)
            ) {
                world.gravity.y = 9.8;
                antiGravity = false;
                gravityIsNormal = true;
                hero.mirror.x = false;
                hero.rotateTo(0, 20);
                console.log("colliding");
            }
            if (hero.overlaps(wallRunBlock) && (!wallRunning || gravityIsNormal)) {
                gravityIsNormal = false;
                world.gravity.y = 0;
                antiGravity = false;
                wallRunning = true;
            } else if (
                hero.overlaps(wallRunBlock) &&
                (wallRunning || !gravityIsNormal)
            ) {
                wallRunning = false;
                gravityIsNormal = true;
            }
        }
        if (wallRunning) {
            hero.applyForce(60, 0);
            hero.rotateTo(-90, 20);
        } else if (!wallRunning && !antiGravity) {
            hero.rotateTo(0, 20);
            hero.applyForce(0, 0);
            world.gravity.y = 9.8;
        }
        // Handles the damage system, the check for the swampGrass ensures the player
        // does not get damaged while standing above the lava due to its hitbox
        if (hero.overlapping(lava) && hero.colliding(swampGrass)) {
            damageTaken++;
            console.log(damageTaken);
        }
        if (damageTaken >= 200) {
            if (currentLevel === 1) {
                death(level1Tiles);
            } else if (currentLevel === 2) {
                death(level2Tiles);
            } else if (currentLevel === 3) {
                death(level3Tiles);
            }
        }
        // Handles Damage in relation to the Health UI and also hit audio
        if (damageTaken === 195) {
            healthVariable = noHealthLeft;
        }
        if (damageTaken >= 10 && damageTaken <= 20) {
            if (!healthRestoring) {
                healthVariable = healthUpperBound;
                hero.tint = color(255, 0, 0);
                if (audioEnabled && lavaHitNorm.audioCount < 1) {
                    lavaHitNorm.play();
                    lavaHitNorm.audioCount = 1;
                }
            }
        } else if (damageTaken >= 40 && damageTaken <= 60) {
            if (!healthRestoring) {
                healthVariable = healthQuarterDown;
                hero.tint = color(255, 0, 0);
                if (audioEnabled && lavaHitNorm.audioCount < 1) {
                    lavaHitNorm.play();
                    lavaHitNorm.audioCount = 1;
                }
            }
        } else if (damageTaken >= 80 && damageTaken <= 100) {
            if (!healthRestoring) {
                healthVariable = halfHealth;
                hero.tint = color(255, 0, 0);
                if (audioEnabled && lavaHitLow.audioCount < 1) {
                    lavaHitLow.play();
                    lavaHitLow.audioCount = 1;
                }
            }
        } else if (damageTaken >= 120 && damageTaken <= 140) {
            if (!healthRestoring) {
                healthVariable = quarterHealthLeft;
                hero.tint = color(255, 0, 0);
                if (audioEnabled && lavaHitHigh.audioCount < 1) {
                    lavaHitHigh.play();
                    lavaHitHigh.audioCount = 1;
                }
            }
        } else if (damageTaken >= 160 && damageTaken <= 180) {
            if (!healthRestoring) {
                healthVariable = healthLowerBound;
                hero.tint = color(255, 0, 0);
                if (audioEnabled && lavaHitHigh.audioCount < 1) {
                    lavaHitHigh.play();
                    lavaHitHigh.audioCount = 1;
                }
            }
        } else {
            lavaHitNorm.audioCount = 0;
            lavaHitLow.audioCount = 0;
            lavaHitHigh.audioCount = 0;
            hero.tint = color(255);
        }
        if (damageTaken === 0) {
            healthVariable = fullHealth;
        }
        // Handles the settings menu
        if (kb.pressed("escape")) {
            if (settingsOpen) {
                $("#dialog").dialog("destroy").remove();
                settingsOpen = false;
            } else if (!settingsOpen && tutorialOpen) {
                tutorialOpen = false;
                return;
            } else if (!settingsOpen && finishMessageOpen) {
                finishMessageOpen = false;
                return;
            } else if (!settingsOpen) {
                settingsDialog();
                settingsOpen = true;
            }
        }
        if (hero.colliding(floatGrassSolo) || hero.colliding(floatGrassRight)) {
            if (hero.overlapping(finishFlagTile) && !finishMessageOpen) {
                console.log("Finish reached!");
                finishedDialogue();
            }
        }
        musicCheck();
    } else if (!riseAnimationPlayed) {
        if (kb.pressed("Enter")) {
            startGame();
        }
    }
    if (kb.pressed("d")) {
        if (!allSprites.debug) {
            allSprites.debug = true;
        } else {
            allSprites.debug = false;
        }
    }
    // Iterate through the array of boars to allow boar to be used singularly
    for (let i = 0; i < boars.length; i++) {
        let boar = boars[i];
        if (boar.overlap(boarBoundLeft)) {
            boar.velocity.x = boarSpeed;
            if (boar.antiGravity) {
                boar.mirror.x = false;
            } else if (!boar.antiGravity) {
                boar.mirror.x = true;
            }
        } else if (boar.overlap(boarBoundRight)) {
            boar.velocity.x = -boarSpeed;
            if (!boar.antiGravity) {
                boar.mirror.x = false;
            } else if (boar.antiGravity) {
                boar.mirror.x = true;
            }
        }
        if (currentLevel === 1) {
            if (hero.colliding(boar) && hero.colliding(level1Tiles)) {
                damageTaken++;
            }
        }
        if (currentLevel === 2) {
            if (hero.colliding(boar) && hero.colliding(level2Tiles)) {
                damageTaken++;
            }
        }
        if (currentLevel === 3) {
            if (hero.colliding(boar) && hero.colliding(level3Tiles)) {
                damageTaken++;
            }
        }
        if (currentLevel === 4) {
            if (hero.colliding(boar) && hero.colliding(level4Tiles)) {
                damageTaken++;
            }
        }
        if (currentLevel === 5) {
            if (hero.colliding(boar) && hero.colliding(level5Tiles)) {
                damageTaken++;
            }
        }
        if (
            !hero.colliding(boar) &&
            !kb.pressing("ArrowRight") &&
            !kb.pressing("ArrowLeft")
        ) {
            hero.velocity.x = 0;
        }
        // Handles health regeneration
        if (!hero.colliding(boar) && !hero.overlapping(lava)) {
            healthRegenerationTimer++; // Increment the regeneration timer
            if (healthRegenerationTimer >= HEALTHREGENERATIONINTERVAL) {
                // If enough time has passed, increase player's health
                damageTaken = Math.ceil(damageTaken / 10) * 10;
                hero.tint = color(255);
                healthRestoring = true;
                damageTaken -= HEALTHREGENERATIONAMOUNT;
                if (damageTaken < 0) {
                    damageTaken = 0; // Ensure health doesn't go below 0
                }
                healthRegenerationTimer = 0; // Reset the regeneration timer
            }
            if (damageTaken === 180) {
                healthVariable = healthLowerBound;
                hero.tint = color(0, 255, 0);
            }
            if (damageTaken === 170) {
                hero.tint = color(255);
            } else if (damageTaken === 140) {
                healthVariable = quarterHealthLeft;
                hero.tint = color(0, 255, 0);
            }
            if (damageTaken === 130) {
                hero.tint = color(255);
            } else if (damageTaken === 100) {
                healthVariable = halfHealth;
                hero.tint = color(0, 255, 0);
            }
            if (damageTaken === 90) {
                hero.tint = color(255);
            } else if (damageTaken === 60) {
                healthVariable = healthQuarterDown;
                hero.tint = color(0, 255, 0);
            }
            if (damageTaken === 50) {
                hero.tint = color(255);
            } else if (damageTaken === 20) {
                healthVariable = healthUpperBound;
                hero.tint = color(0, 255, 0);
            }
            if (damageTaken === 10) {
                hero.tint = color(255);
            }
        } else {
            // Reset the regeneration timer if the player is in contact with hazards
            healthRegenerationTimer = 0;
            healthRestoring = false;
        }
    }
    //}
    // I honestly have no clue what this does but every example online had it) and everything
    // breaks without it
    pop();
    if (riseAnimationPlayed) {
        // Draw UI elements here
        drawUI();
    }
}

// Handles the health bar in the upper left corner
function drawUI() {
    let resizedWindowHeight = windowHeight / SCALEFACTOR;
    let resizedWindowWidth = windowWidth / SCALEFACTOR;

    healthQuarterDown.resize(52.5, 8);
    fullHealth.resize(52.5, 8);
    halfHealth.resize(52.5, 8);
    quarterHealthLeft.resize(52.5, 8);
    noHealthLeft.resize(52.5, 8);
    healthLowerBound.resize(52.5, 8);
    healthUpperBound.resize(52.5, 8);

    image(healthVariable, resizedWindowWidth / HEALTHUIOFFSET, resizedWindowHeight / HEALTHUIOFFSET);
}

// Checks whether audio is playing
function musicCheck() {
    if (audioEnabled && !backgroundMusic.isPlaying()) {
        backgroundMusic.play();
    } else if (!audioEnabled && backgroundMusic.isPlaying()) {
        backgroundMusic.pause();
    }
}

// Function that makes the player jump
function spriteJumpAni() {
    hero.changeAni("jump");
}
/******************
 * Main js file for platformer game
 * Created by Hunter Chapman
 * Level 2 Programming assesment
 ******************/

// Constants
const SPRITEYOFFSET = 12;
const CAMSPRITEYOFFSET = 3;
const SPRITEWIDTHOFFSET = 2;
const WINDOWHEIGHTOFFSET = 360;
const SCALEFACTOR = 5;
const HEROFRAMEDELAY = 8;
const JUMPTOTALFRAMES = 5;
const JUMPHEIGHT = 18;
const HEROSPEED = 2.5;
const TILESIZE = 2;
const TILEXOFFSET = 400;
const LAVAHEIGHT = 16 * 0.75;
const PIXELSCALE = "pixelated x5";
const HEALTHREGENERATIONINTERVAL = 60;
const HEALTHREGENERATIONAMOUNT = 10;

// Predefines
let hero;
let floor;
let spriteSheetHero;
let bgImage;
let plattyBackground;
let nameHasBeenInputted = false;
let heroIsJumping = false;
let jumpAniDone = false;
let riseAnimationPlayed = false;
let jumpFrameCount = 0;
let propTiles;
let groundTiles;
let swampTiles;
let level1Tiles;
let airTile;
let lavaTile;
let makeCameraStatic = false;
let damageTaken = 0;
let deathMessagePlayed = false;
let nameInput;
let audioEnabled;
let lavaHit;
let lavaHitLow;
let lavaHitHigh;
let backgroundMusic;
let altTiles;
let settingsOpen = false;
let floatingDirtLeft;
let floatingDirtRight;
let floatingDirtSolo;
let finishFlag;
let tutorialOpen = false;
let finishMessageOpen = false;
let time = 0;
let timerHasStarted = false;
let timerInterval;
let currentLevel;
let boar;
let boarSheet;
let boarsSpawned = 0;
let boarPosX;
let boarWalkTime = 0;
let boars = [];
let healthQuarterDown;
let fullHealth;
let halfHealth;
let quarterHealthLeft;
let noHealthLeft;
let healthLowerBound;
let healthUpperBound;
let healthVariable;
let healthRegenerationTimer = 0;
let healthRestoring = false;
let tilesFound = 0;
let walkTimeLeft;
let walkTimeRight;
let boarSpeed;
let floatingDirtMiddle;

/* Preload function, currently just loading images,
 * tilesheets, spritesheets, etc */
function preload() {
  spriteSheetHero = loadImage("/resources/questKid.png");
  bgImage = loadImage("/resources/loginPageBackground.jpeg");
  plattyBackground = loadImage("/resources/gameBackground.png");
  swampTiles = loadImage("/resources/tilesets/swampTiles.png");
  groundTiles = loadImage("/resources/tilesets/groundTiles.png");
  propTiles = loadImage("/resources/tilesets/propTiles.png");
  airTile = loadImage("/resources/tilesets/air.png");
  lavaTile = loadImage("resources/tilesets/lava.png");
  altTiles = loadImage("/resources/tilesets/groundTiles.png");
  lavaHitLow = loadSound("https://codehs.com/uploads/3dfdda4b3e49065129b8840c7628d9ca");
  lavaHitHigh = loadSound("https://codehs.com/uploads/e9521e85ad516909f5f6c0993dac8c40");
  lavaHitNorm = loadSound("https://codehs.com/uploads/1def79641167cc982cc4a1fa93379beb");
  backgroundMusic = loadSound("https://codehs.com/uploads/b7bc2716f9b557de6ecd6f9ddf48944a"); // Find audio
  floatingDirtRight = loadImage("/resources/tilesets/floatingDirtRight.png");
  floatingDirtLeft = loadImage("/resources/tilesets/floatingDirtLeft.png");
  floatingDirtSolo = loadImage("/resources/tilesets/floatingDirtSolo.png");
  floatingDirtMiddle = loadImage("/resources/tilesets/floatingDirtMiddle.png");
  finishFlag = loadImage("/resources/tilesets/finishFlag.png");
  boarSheet = loadImage("/resources/tilesets/boar.png");
  healthQuarterDown = loadImage("/resources/tilesets/healthQuarterDown.png");
  halfHealth = loadImage("/resources/tilesets/halfHealth.png");
  fullHealth = loadImage("/resources/tilesets/fullHealth.png");
  quarterHealthLeft = loadImage("/resources/tilesets/quarterHealth.png");
  noHealthLeft = loadImage("/resources/tilesets/emptyHealth.png");
  healthLowerBound = loadImage("/resources/tilesets/healthLowerBound.png");
  healthUpperBound = loadImage("/resources/tilesets/healthUpperBound.png");
}

// Setup function, creates canvas, sprites, and assigns animations
function setup() {
  // Get window height before it is upscaled by the PIXELSCALE in create canvas
  let unalteredWindowHeight = (windowHeight - WINDOWHEIGHTOFFSET) / SCALEFACTOR;
  let unalteredWindowWidth = windowWidth / SCALEFACTOR;

  // Create canvas
  cnv = new Canvas(unalteredWindowWidth, unalteredWindowHeight, PIXELSCALE);
  allSprites.pixelPerfect = true;
  console.log("Canvas is (width/height): " + canvas.w + "/" + canvas.h);

  // Create sprite
  hero = new Sprite(
    unalteredWindowWidth / SPRITEWIDTHOFFSET,
    unalteredWindowHeight - SPRITEYOFFSET,
    32,
    32,
    "k",
  );
  console.log("Hero's (sprite) X/Y coordinates are: " + hero.x + "/" + hero.y);
  hero.rotationLock = true;
  hero.spriteSheet = spriteSheetHero;
  hero.anis.offset.x = SPRITEWIDTHOFFSET;
  hero.anis.offset.y = -5;
  hero.anis.frameDelay = HEROFRAMEDELAY;
  world.gravity.y = 9.8;

  // Create sprite animation and assign sleeping ani to sprite
  hero.addAnis({
    run: {
      row: 0,
      frames: 8,
    },
    jump: {
      row: 1,
      frames: 6,
    },
    roll: {
      row: 2,
      frames: 5,
      frameDelay: 14,
    },
    turn: {
      row: 3,
      frames: 7,
    },
    stand: {
      row: 3,
      frames: 1,
    },
    sleeping: {
      row: 21,
      frames: 10,
    },
    riseFromGround: {
      row: 23,
      frames: 6,
    },
    sword: {
      row: 12,
      frames: 10,
    },
  });

  hero.changeAni("sleeping");
  hero.w = 13;
  hero.h = 15;
  hero.friction = 0;
  hero.wallCollisionHappened = false;
  hero.tutorialAlertHasPlayed = false;
}

// Function that adds an event listener to allow the user to start
// typing on the start page and have it automatically select the name input
// box
document.addEventListener("DOMContentLoaded", function () {
  let nameInput = document.getElementById("nameInput");

  // Focus on input when user starts typing
  document.addEventListener("keydown", function () {
    nameInput.focus();
  });

  // Remove outline when input is focused
  nameInput.addEventListener("focus", function () {
    nameInput.classList.add("noOutline");
  });

  // Add outline when input is blurred
  nameInput.addEventListener("blur", function () {
    nameInput.classList.remove("noOutline");
  });
});

function audioCheck() {
  audioEnabled = document.getElementById("audio").checked;
  if (audioEnabled) {
    console.log("Audio has been turned on");
    if (!backgroundMusic.isPlaying()) {
      backgroundMusic.play();
    }
  } else if (!audioEnabled) {
    console.log("Audio has been turned off");
    if (backgroundMusic.isPlaying()) {
      backgroundMusic.pause();
    }
  }
}

// Game start Function, called on click of play button, resizes-
// canvas, adds background, removes html elements
function startGame() {
  healthVariable = fullHealth;
  audioEnabled = document.getElementById("audio").checked;
  // First, check if a name has been inputted
  if (!nameInputted()) {
    document.getElementById("userNameHint").textContent =
      "Please enter a name containing only letters";
  } else if (nameInputted()) {
    // Removes Header and play button elements, they're being-
    // removed instead of hidden as when theyre hidden the canvas-
    // can't use the full screen size without scrolling otherwise
    removeElement("htmlElements");

    //Create new variables with accurate window width/height
    let resizedWindowHeight = windowHeight / SCALEFACTOR;
    let resizedWindowWidth = windowWidth / SCALEFACTOR;

    bgImage = plattyBackground;
    allSprites.pixelPerfect = true;
    console.log("Canvas has been resized, game started");
    /*// Reposition sprite 'hero' to center of new view
        hero.position.x = resizedWindowWidth / SPRITEWIDTHOFFSET;
        hero.position.y = resizedWindowHeight - SPRITEYOFFSET;
        hero.changeAni('riseFromGround');
        hero.animation.looping = false;
        riseAnimationPlayed = true;*/
    // Calls the function that creates the tiles
    startLevel1();
    // Remove canvas and recreate it with new values because
    // resizeCanvas() doesn't work for some reason
    canvas.remove();
    cnv = new Canvas(resizedWindowWidth, resizedWindowHeight, PIXELSCALE);
    hero.cameraFollowY = true;
    hero.cameraFollowX = true;
    hero.collider = "dynamic";
  }
}

function spawnMobs(type, tileset, speed, startDir) {
  if (type === "boar") {
    boarSpeed = speed;
    boarWalkingLeft = startDir === "left";
    let boarSpawnPoints = findTile(tileset, "boar");
    for (let i = 0; i < boarSpawnPoints.length; i++) {
      initiateSpawn(
        "boar",
        boarSpawnPoints[i].x,
        boarSpawnPoints[i].y,
        1,
        speed,
        startDir,
      );
    }
  } else if (type === "player") {
    let playerSpawnPoint = findTile(tileset, "player");
    for (let i = 0; i < playerSpawnPoint.length; i++) {
      hero.position.x = playerSpawnPoint[i].x;
      hero.position.y = playerSpawnPoint[i].y;
      hero.changeAni("riseFromGround");
      hero.animation.looping = false;
      riseAnimationPlayed = true;
    }
  }
}

function initiateSpawn(type, x, y, amount, speed, startDir) {
  for (let i = 0; i < amount; i++) {
    if (type === "boar") {
      let newBoar = createBoar(x, y, speed, startDir); // Function to create a new boar
      boars.push(newBoar); // Add the new boar to the array
    }
  }
}

function createBoar(x, y, speed, startDir) {
  let newBoar = createSprite(x, y - 8, 48, 32, "k"); // Create a new boar sprite
  if (startDir === "left") {
    newBoar.velocity.x = -speed;
  } else {
    newBoar.velocity.x = speed;
  }
  newBoar.spriteSheet = boarSheet;
  newBoar.addAnis({
    walk: {
      frames: 6,
    },
  });
  newBoar.rotationLock = true;
  newBoar.w = 40;
  newBoar.h = 20;
  console.log("Boar spawned");
  boarsSpawned++;
  return newBoar;
}

function removeMob(type) {
  if (type === "boar") {
    if (boars.length > 0) {
      for (let i = boars.length - 1; i >= 0; i--) {
        let removedBoar = boars.splice(i, 1)[0]; // Remove the first boar from the array
        removedBoar.remove(); // Remove the sprite from the canvas
        console.log("Boar removed");
      }
    }
  } else if (type === "player") {
    if (playerSpawnPoint.length > 0) {
      playerSpawnPoint.length = 0;
    }
  }
}

function findTile(tileset, type) {
  if (type === "boar") {
    let boarSpawnPoints = [];
    for (let i = 0; i < tileset.length; i++) {
      if (tileset[i].tile === "B") {
        // Check if the tile type is 'B' (boar)
        boarSpawnPoints.push({
          // Add the spawn point to the array
          x: tileset[i].x,
          y: tileset[i].y,
        });
      }
    }
    return boarSpawnPoints;
  }
  if (type === "player") {
    let playerSpawn = [];
    for (let i = 0; i < tileset.length; i++) {
      if (tileset[i].tile === "P") {
        playerSpawn.push({
          x: tileset[i].x,
          y: tileset[i].y,
        });
      }
    }
    return playerSpawn;
  }
}

function startLevel1() {
  currentLevel = 1;
  //Create new variables with accurate window width/height
  let resizedWindowHeight = windowHeight / SCALEFACTOR;
  let resizedWindowWidth = windowWidth / SCALEFACTOR;
  let xCoord = hero.position.x - TILEXOFFSET;
  let yCoord = resizedWindowHeight - 15;
  console.log("creating tiles for first level");
  swampGrass = new Group();
  swampGrass.tile = "s";
  swampGrass.collider = "static";
  swampGrass.spriteSheet = swampTiles;
  swampGrass.addAni({
    w: 16,
    h: 16,
    row: 0,
    col: 1,
  });

  swampDirt = new Group();
  swampDirt.tile = "d";
  swampDirt.collider = "static";
  swampDirt.spriteSheet = swampTiles;
  swampDirt.addAni({
    w: 16,
    h: 16,
    row: 1,
    col: 1,
  });

  grassLeftCorner = new Group();
  grassLeftCorner.tile = "l";
  grassLeftCorner.collider = "static";
  grassLeftCorner.spriteSheet = swampTiles;
  grassLeftCorner.addAni({
    w: 16,
    h: 16,
    row: 0,
    col: 5,
  });

  grassBottomLeftCorner = new Group();
  grassBottomLeftCorner.tile = "L";
  grassBottomLeftCorner.collider = "static";
  grassBottomLeftCorner.spriteSheet = swampTiles;
  grassBottomLeftCorner.addAni({
    w: 16,
    h: 16,
    row: 4,
    col: 7,
  });

  grassRightCorner = new Group();
  grassRightCorner.tile = "r";
  grassRightCorner.collider = "static";
  grassRightCorner.spriteSheet = swampTiles;
  grassRightCorner.addAni({
    w: 16,
    h: 16,
    row: 0,
    col: 0,
  });

  grassBottomRightCorner = new Group();
  grassBottomRightCorner.tile = "R";
  grassBottomRightCorner.collider = "static";
  grassBottomRightCorner.spriteSheet = swampTiles;
  grassBottomRightCorner.addAni({
    w: 16,
    h: 16,
    row: 4,
    col: 10,
  });

  leftWallCheck = new Group();
  leftWallCheck.tile = "a";
  leftWallCheck.collider = "none";
  leftWallCheck.image = airTile;
  leftWallCheck.w = 16;
  leftWallCheck.h = 16;

  cameraDisable = new Group();
  cameraDisable.tile = "k";
  cameraDisable.collider = "none";
  cameraDisable.image = airTile;
  cameraDisable.w = 16;
  cameraDisable.h = 16;

  air = new Group();
  air.tile = "A";
  air.collider = "static";
  air.image = airTile;
  air.w = 26;
  air.h = 16;

  lava = new Group();
  lava.tile = "m";
  lava.collider = "none";
  lavaTile.resize(16, 16);
  lava.image = lavaTile;
  lavaHitNorm.audioCount = 0;
  lavaHitHigh.audioCount = 0;
  lavaHitLow.audioCount = 0;

  floatGrassLeft = new Group();
  floatGrassLeft.tile = "f";
  floatGrassLeft.collider = "static";
  floatingDirtLeft.resize(16, 16);
  floatGrassLeft.image = floatingDirtLeft;

  floatGrassMiddle = new Group();
  floatGrassMiddle.tile = "M";
  floatGrassMiddle.collider = "static";
  floatingDirtMiddle.resize(16, 16);
  floatGrassMiddle.image = floatingDirtRight;
 
  floatGrassRight = new Group();
  floatGrassRight.tile = "F";
  floatGrassRight.collider = "static";
  floatingDirtRight.resize(16, 16);
  floatGrassRight.image = floatingDirtRight;

  floatGrassSolo = new Group();
  floatGrassSolo.tile = "D";
  floatGrassSolo.collider = "static";
  floatingDirtSolo.resize(16, 16);
  floatGrassSolo.image = floatingDirtSolo;

  finishFlagTile = new Group();
  finishFlagTile.tile = "T";
  finishFlag.resize(40, 35);
  finishFlagTile.collider = "none";
  finishFlagTile.image = finishFlag;
  finishFlagTile.w = 16;
  finishFlagTile.h = 16;

  boarSpawnTile = new Group();
  boarSpawnTile.tile = "B";
  boarSpawnTile.collider = "none";
  boarSpawnTile.image = airTile;
  boarSpawnTile.w = 16;
  boarSpawnTile.h = 16;

  boarBoundLeft = new Group();
  boarBoundLeft.tile = "b";
  boarBoundLeft.collider = "none";
  boarBoundLeft.image = airTile;
  boarBoundLeft.w = 16;
  boarBoundLeft.h = 16;

  boarBoundRight = new Group();
  boarBoundRight.tile = "n";
  boarBoundRight.collider = "none";
  boarBoundRight.image = airTile;
  boarBoundRight.w = 16;
  boarBoundRight.h = 16;

  playerSpawnPoint = new Group();
  playerSpawnPoint.tile = "P";
  playerSpawnPoint.collider = "none";
  playerSpawnPoint.image = airTile;
  playerSpawnPoint.w = 16;
  playerSpawnPoint.h = 16;

  level1Tiles = new Tiles(
    [
      ".......A........ka............................................................................ak........A...",
      ".......A........ka............................................................................ak........A...",
      ".......A........ka....................................................................T.......ak........A...",
      ".......A........ka....................................................................D.......ak........A...",
      ".......A........ka..............................................................D.............ak........A...",
      ".......A........ka........................................................fF..................ak........A...",
      ".......A........ka.................................................D..........................ak........A...",
      ".......A........ka..........................................fF................................ak........A...",
      ".......A........ka...................................fF.......................................ak........A...",
      ".......A........ka..................P.......b...B..n...............b....B....n................ak........A...",
      "ssssssssssssssssssssssssssssssssssssssssslmmrsssssslmmmrssssslmmmmmrssssssssslmmmrssssssssssssssssssssssssss",
      "dddddddddddddddddddddddddddddddddddddddddLssRddddddLsssRdddddLsssssRdddddddddLsssRdddddddddddddddddddddddddd",
      "dddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddd",
      "dddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddd",
      "dddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddd",
      "dddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddd",
      "dddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddd",
      "dddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddd",
      "dddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddd",
    ],
    xCoord,
    yCoord,
    16,
    16,
  );
  spawnMobs("player", level1Tiles);
  spawnMobs("boar", level1Tiles, 0.5, "left");
}

function startLevel2() {
  //Create new variables with accurate window width/height
  let resizedWindowHeight = windowHeight / SCALEFACTOR;
  let resizedWindowWidth = windowWidth / SCALEFACTOR;
  hero.collider = "dynamic";
  let xCoord = hero.position.x - TILEXOFFSET;
  let yCoord = resizedWindowHeight - 15;

  canvas.remove();
  cnv = new Canvas(resizedWindowWidth, resizedWindowHeight, PIXELSCALE);

  currentLevel = 2;
  console.log("creating tiles for second level");

  level2Tiles = new Tiles(
    [
      ".......A........ka............................................................................ak........A...",
      ".......A........ka............................................................................ak........A...",
      ".......A........ka....................................................................T.......ak........A...",
      ".......A........ka....................................................................D.......ak........A...",
      ".......A........ka..............................................................D.............ak........A...",
      ".......A........ka........................................................fF..................ak........A...",
      ".......A........ka.................................................D..........................ak........A...",
      ".......A........ka................................b....B..n....D..............................ak........A...",
      ".......A........ka............................D...fMfMfMfMF...................................ak........A...",
      ".......A........ka.................P..........................................................ak........A...",
      "ssssssssssssssssssssssssssssssssssssssssslmmmmmmmmmmmmmmmmmmmmmmmmmrssssssssslmmmrssssssssssssssssssssssssss",
      "dddddddddddddddddddddddddddddddddddddddddLsssssssssssssssssssssssssRdddddddddLsssRdddddddddddddddddddddddddd",
      "dddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddd",
      "dddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddd",
      "dddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddd",
      "dddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddd",
      "dddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddd",
      "dddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddd",
      "dddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddd",
    ],
    xCoord,
    yCoord,
    16,
    16,
  );
  spawnMobs("player", level2Tiles);
  spawnMobs("boar", level2Tiles, 0.5, "left");
}

function startLevel3() {
  //Create new variables with accurate window width/height
  let resizedWindowHeight = windowHeight / SCALEFACTOR;
  let resizedWindowWidth = windowWidth / SCALEFACTOR;
  hero.position.x = resizedWindowWidth / SPRITEWIDTHOFFSET;
  hero.position.y = resizedWindowHeight - SPRITEYOFFSET;
  hero.changeAni("riseFromGround");
  hero.cameraFollowY = true;
  hero.cameraFollowX = true;
  hero.collider = "dynamic";
  let xCoord = hero.position.x - TILEXOFFSET;
  let yCoord = resizedWindowHeight - 15;

  canvas.remove();
  cnv = new Canvas(resizedWindowWidth, resizedWindowHeight, PIXELSCALE);

  currentLevel = 3;
  console.log("creating tiles for third level");

  level2Tiles = new Tiles(
    [
      ".......A........ka............................................................................ak........A...",
      ".......A........ka............................................................................ak........A...",
      ".......A........ka....................................................................T.......ak........A...",
      ".......A........ka....................................................................D.......ak........A...",
      ".......A........ka..............................................................D.............ak........A...",
      ".......A........ka........................................................fF..................ak........A...",
      ".......A........ka.................................................D..........................ak........A...",
      ".......A........ka..........................................fF................................ak........A...",
      ".......A........ka...................................fF.......................................ak........A...",
      ".......A........ka................P...........................................................ak........A...",
      "ssssssssssssssssssssssssssssssssssssssssslmmrsssssslmmmrssssslmmmmmrssssssssslmmmrssssssssssssssssssssssssss",
      "dddddddddddddddddddddddddddddddddddddddddLssRddddddLsssRdddddLsssssRdddddddddLsssRdddddddddddddddddddddddddd",
      "dddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddd",
      "dddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddd",
      "dddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddd",
      "dddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddd",
      "dddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddd",
      "dddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddd",
      "dddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddd",
    ],
    xCoord,
    yCoord,
    16,
    16,
  );
}

// Function that utilises jQuery to bring a pop up dialogue to the screen
// credit to ChatGPT for the base of the jQuery function as i wouldn't have
// even known where to start otherwise
// Note: Dialog is spelled without the -ue as it seems to break jQuery when spelt with
function settingsDialog() {
  settingsOpen = true;
  // Create a div element to hold the dialog content
  let dialogContent =
    '<div id="dialog" title="Settings">' +
    '<input style="margin: 0; auto"type="checkbox" id="musicEnabled">' +
    '<label for="musicEnabled">  Music enabled</label>' +
    "</div>";

  // Append the dialog content to the body
  $("body").append(dialogContent);

  // Change the value of the checkbox on open to checked/unchecked
  // dependent on the value of the audioEnabled variable (bool)
  $("#musicEnabled").prop("checked", audioEnabled);

  // Bind a function to the checkbox's change event to update audioEnabled
  $("#musicEnabled").change(function () {
    audioEnabled = this.checked;
    console.log("Music enabled: " + audioEnabled);
  });

  // Initialize the dialog
  $("#dialog").dialog({
    autoOpen: true,
    modal: true,
    buttons: [], // Empty buttons to remove "Save" button

    close: function () {
      settingsOpen = false;
      $(this).dialog("destroy").remove(); // Remove dialog from DOM after closing
    },
  });
  $("<button>").appendTo("#dialog").focus().remove();
}

// Function that starts a timer when it's called
function timerStart() {
  if (!timerHasStarted) {
    console.log("Timer Started!");
    timerHasStarted = true;
  }
  time++;
}

function timerStop() {
  clearInterval(timerInterval);
  timerHasStarted = false;
}

// Another jQuery UI dialogue box, this creates the pop up at the start of the first level
// no ChatGPT this time, i simply modified the previous dialogue box
function tutorialDialogueFunc() {
  tutorialOpen = true;
  let tutorialDialogue =
    '<div id="dialog" title="Tutorial">' +
    '<h1 style="text-align: center">Level 1</h1>' +
    '<p style="text-align: center">Welcome to the first level ' +
    nameInput +
    "! Use the arrow keys to move around and jump, and avoid the lava, it won't kill you immediately, but it'll hurt!<br><br>When you get to the flag at the end of the level, walk (or jump) into it to complete the level!<br><br>P.S. You should play this in full screen for the best experience!</p>" +
    "</div>";
  $("body").append(tutorialDialogue);

  // Initialize the dialog
  $("#dialog").dialog({
    autoOpen: true,
    modal: true,
    buttons: {
      Ok: function () {
        $(this).dialog("close");
      },
    },
    close: function () {
      timerInterval = setInterval(timerStart, 1000);
      $(this).dialog("destroy").remove(); // Remove dialog from DOM after closing
      tutorialOpen = false;
    },
  });
}

// Level finished
function finishedDialogue() {
  finishMessageOpen = true;
  let finishedDialogue =
    '<div id="dialog" title="Level ' +
    currentLevel +
    ' Completed">' +
    '<h1 style="text-align: center">Level ' +
    currentLevel +
    " Completed!</h1>" +
    '<p style="text-align: center">Congratulations ' +
    nameInput +
    "! You completed level " +
    currentLevel +
    " in " +
    time +
    " seconds!<br><br>Press Ok or close the window with the X in the top right corner to go to the next level</p>" +
    "</div>";
  $("body").append(finishedDialogue);

  // Initialize the dialog
  $("#dialog").dialog({
    autoOpen: true,
    modal: true,
    buttons: {
      Ok: function () {
        $(this).dialog("close");
      },
    },
    close: function () {
      timerStop();
      level1Tiles.removeAll();
      level2Tiles.removeAll();
      level3Tiles.removeAll();
      if (currentLevel === 1) {
        removeMob("boar");
        removeMob("player");
        startLevel2();
      } else if (currentLevel === 2) {
        startLevel3();
      }
      $(this).dialog("destroy").remove(); // Remove dialog from DOM after closing
      finishMessageOpen = false;
    },
  });
}

// Function that's called whenever the window resizes that adjusts the location
// of the sprite, tiles, etc
function windowResized() {
  // Create new variables with accurate window width/height
  let resizedWindowHeight = windowHeight / SCALEFACTOR;
  let resizedWindowWidth = windowWidth / SCALEFACTOR;
  let heroPreviousX = hero.position.x;
  let heroPreviousY = hero.position.y;
  console.log("Window resized");
  // Remove canvas and recreate it with new values because
  // resizeCanvas() doesn't work for some reason
  canvas.remove();
  cnv = new Canvas(resizedWindowWidth, resizedWindowHeight, PIXELSCALE);
  allSprites.pixelPerfect = true;
  // Reposition sprite 'hero' to center of new view
  if (!hero.cameraFollowX && !hero.cameraFollowY) {
    hero.position.x = resizedWindowWidth / SPRITEWIDTHOFFSET;
  } else if (hero.cameraFollowX && hero.cameraFollowY) {
    hero.position.x = heroPreviousX;
    hero.position.y = heroPreviousY;
  }
}

// Function to remove an html element when called
function removeElement(idToRemove) {
  let element = document.getElementById(idToRemove);
  return element.parentNode.removeChild(element);
}

// Function to check whether a name has been inputted into the input box on call,
// and return the value true or false respective of whether a name is present
function nameInputted() {
  nameInput = document.getElementById("nameInput").value;
  if (
    nameInput === "" ||
    nameInput === " " ||
    nameInput === "" ||
    nameInput === " " ||
    nameInput === null
  ) {
    return false;
  } else if (nameInput.length > 0) {
    if (nameIsValid(nameInput)) {
      nameHasBeenInputted = true;
      return true;
    } else {
      return false;
    }
  }
}

// Function to check whether the inputted name contains only letters
// regex is funky and confusing so i don't claim this as my own code,
// credits are below.
function nameIsValid(name) {
  // Credit: geeksforgeeks.org for the regex code
  let letterTest = /^[a-zA-Z]+$/;
  if (letterTest.test(name)) {
    return true;
  } else if (!letterTest.test(name)) {
    return false;
  }
}

function death(tileset) {
    spawnMobs("player", tileset);
    damageTaken = 0;
    if (!deathMessagePlayed) {
      alert(
        "Sorry " +
          nameInput +
          ", you died! Resetting you to the start of your current level.",
      );
      deathMessagePlayed = true;
    }
}

// p5play draw function, runs once
function draw() {
  clear();
  background(bgImage);

  // Don't know how this works or what it does but it allows a static UI image and i trust
  // stackoverflow enough to know that
  push();

  // Apply camera transformation
  translate(-camera.x, -camera.y);
  if (hero.cameraFollowY) {
    camera.y = hero.y - CAMSPRITEYOFFSET;
  }
  if (hero.cameraFollowX) {
    camera.x = hero.x;
  }
  if (riseAnimationPlayed) {
    if (kb.pressing("ArrowLeft")) {
      if (tutorialOpen || settingsOpen || finishMessageOpen) {
        return;
      }
      hero.mirror.x = true;
      hero.vel.x = -HEROSPEED;
      hero.changeAni("run");
    }
    if (kb.released("ArrowLeft")) {
      if (tutorialOpen || settingsOpen || finishMessageOpen) {
        return;
      }
      hero.vel.x = 0;
      hero.changeAni("stand");
    }
    if (kb.pressing("ArrowRight")) {
      if (tutorialOpen || settingsOpen || finishMessageOpen) {
        return;
      }
      hero.mirror.x = false;
      hero.vel.x = HEROSPEED;
      hero.changeAni("run");
    }
    if (kb.released("ArrowRight")) {
      if (tutorialOpen || settingsOpen || finishMessageOpen) {
      }
      hero.vel.x = 0;
      hero.changeAni("stand");
    }
    if (kb.pressing("ArrowUp")) {
      if (tutorialOpen || settingsOpen || finishMessageOpen) {
        return;
      }
      if (hero.vel.y === 0) {
        spriteJumpAni();
        hero.vel.y = JUMPHEIGHT;
      }
    }
    if (hero.colliding(level1Tiles || level2Tiles || level3Tiles) == true) {
      hero.changeAni("stand");
      hero.isJumping = false;
    }
    if (hero.overlap(cameraDisable) == true) {
      hero.cameraFollowX = false;
    }
    if (hero.overlap(leftWallCheck) == true) {
      hero.cameraFollowX = true;
    }
    if (hero.colliding(level1Tiles) == true && !hero.tutorialAlertHasPlayed) {
      tutorialDialogueFunc();
      hero.tutorialAlertHasPlayed = true;
    }
    if (hero.overlapping(lava) && hero.colliding(swampGrass)) {
      damageTaken++;
    }
    if (damageTaken >= 200) {
      if (currentLevel === 1){
        death(level1Tiles);
      } else if (currentLevel === 2) {
          death(level2Tiles)
      } else if (currentLevel === 3) {
          death(level3Tiles)
      }
    }
    if (damageTaken === 195) {
      healthVariable = noHealthLeft;
    }
    if (damageTaken >= 10 && damageTaken <= 20) {
      if (!healthRestoring) {
        healthVariable = healthUpperBound;
        hero.tint = color(255, 0, 0);
        if (audioEnabled && lavaHitNorm.audioCount < 1) {
          lavaHitNorm.play();
          lavaHitNorm.audioCount = 1;
        }
      }
    } else if (damageTaken >= 40 && damageTaken <= 60) {
      if (!healthRestoring) {
        healthVariable = healthQuarterDown;
        hero.tint = color(255, 0, 0);
        if (audioEnabled && lavaHitNorm.audioCount < 1) {
          lavaHitNorm.play();
          lavaHitNorm.audioCount = 1;
        }
      }
    } else if (damageTaken >= 80 && damageTaken <= 100) {
      if (!healthRestoring) {
        healthVariable = halfHealth;
        hero.tint = color(255, 0, 0);
        if (audioEnabled && lavaHitLow.audioCount < 1) {
          lavaHitLow.play();
          lavaHitLow.audioCount = 1;
        }
      }
    } else if (damageTaken >= 120 && damageTaken <= 140) {
      if (!healthRestoring) {
        healthVariable = quarterHealthLeft;
        hero.tint = color(255, 0, 0);
        if (audioEnabled && lavaHitHigh.audioCount < 1) {
          lavaHitHigh.play();
          lavaHitHigh.audioCount = 1;
        }
      }
    } else if (damageTaken >= 160 && damageTaken <= 180) {
      if (!healthRestoring) {
        healthVariable = healthLowerBound;
        hero.tint = color(255, 0, 0);
        if (audioEnabled && lavaHitHigh.audioCount < 1) {
          lavaHitHigh.play();
          lavaHitHigh.audioCount = 1;
        }
      }
    } else {
      lavaHitNorm.audioCount = 0;
      lavaHitLow.audioCount = 0;
      lavaHitHigh.audioCount = 0;
      hero.tint = color(255);
    }
    if (damageTaken === 0) {
      healthVariable = fullHealth;
    }

    if (kb.pressed("escape")) {
      if (settingsOpen) {
        $("#dialog").dialog("destroy").remove();
        settingsOpen = false;
      } else if (!settingsOpen && tutorialOpen) {
        tutorialOpen = false;
        return;
      } else if (!settingsOpen && finishMessageOpen) {
        finishMessageOpen = false;
        return;
      } else if (!settingsOpen) {
        settingsDialog();
        settingsOpen = true;
      }
    }
    if (hero.collides(floatGrassSolo)) {
      if (hero.overlapping(finishFlagTile) && !finishMessageOpen) {
        console.log("Finish reached!");
        finishedDialogue();
      }
    }
    musicCheck();
  } else if (!riseAnimationPlayed) {
    if (kb.pressed("Enter")) {
      startGame();
    }
  }
  if (kb.pressed("d")) {
    if (!allSprites.debug) {
      allSprites.debug = true;
    } else {
      allSprites.debug = false;
    }
  }
  if (boarsSpawned > 0) {
    // Iterate through the array of boars
    for (let i = 0; i < boars.length; i++) {
      let boar = boars[i];
      // Update boar's position based on boarWalkTime
      if (boar.overlap(boarBoundLeft)) {
        boar.velocity.x = boarSpeed;
        boar.mirror.x = true;
      } else if (boar.overlap(boarBoundRight)) {
        boar.velocity.x = -boarSpeed;
        boar.mirror.x = false;
      }
      if (currentLevel === 1) {
        if (hero.colliding(boar) && hero.colliding(level1Tiles)) {
          damageTaken++;
        }
      }
      if (currentLevel === 2) {
        if (hero.colliding(boar) && hero.colliding(level2Tiles)) {
          damageTaken++;
        }
      }
      if (
        !hero.colliding(boar) &&
        !kb.pressing("ArrowRight") &&
        !kb.pressing("ArrowLeft")
      ) {
        hero.velocity.x = 0;
      }
      if (!hero.colliding(boar) && !hero.overlapping(lava)) {
        healthRegenerationTimer++; // Increment the regeneration timer
        if (healthRegenerationTimer >= HEALTHREGENERATIONINTERVAL) {
          // If enough time has passed, increase player's health
          damageTaken = Math.ceil(damageTaken / 10) * 10;
          hero.tint = color(255);
          healthRestoring = true;
          damageTaken -= HEALTHREGENERATIONAMOUNT;
          if (damageTaken < 0) {
            damageTaken = 0; // Ensure health doesn't go below 0
          }
          healthRegenerationTimer = 0; // Reset the regeneration timer
        }
        if (damageTaken === 180) {
          healthVariable = healthLowerBound;
          hero.tint = color(0, 255, 0);
        }
        if (damageTaken === 170) {
          hero.tint = color(255);
        } else if (damageTaken === 140) {
          healthVariable = quarterHealthLeft;
          hero.tint = color(0, 255, 0);
        }
        if (damageTaken === 130) {
          hero.tint = color(255);
        } else if (damageTaken === 100) {
          healthVariable = halfHealth;
          hero.tint = color(0, 255, 0);
        }
        if (damageTaken === 90) {
          hero.tint = color(255);
        } else if (damageTaken === 60) {
          healthVariable = healthQuarterDown;
          hero.tint = color(0, 255, 0);
        }
        if (damageTaken === 50) {
          hero.tint = color(255);
        } else if (damageTaken === 20) {
          healthVariable = healthUpperBound;
          hero.tint = color(0, 255, 0);
        }
        if (damageTaken === 10) {
          hero.tint = color(255);
        }
      } else {
        // Reset the regeneration timer if the player is in contact with hazards
        healthRegenerationTimer = 0;
        healthRestoring = false;
      }
    }
  }
  // I honestly have no clue what this does but every example online had it) and everything
  // breaks without it
  pop();
  if (riseAnimationPlayed) {
    // Draw UI elements here
    drawUI();
  }
}

function drawUI() {
  let resizedWindowHeight = windowHeight / SCALEFACTOR;
  let resizedWindowWidth = windowWidth / SCALEFACTOR;

  healthQuarterDown.resize(52.5, 8);
  fullHealth.resize(52.5, 8);
  halfHealth.resize(52.5, 8);
  quarterHealthLeft.resize(52.5, 8);
  noHealthLeft.resize(52.5, 8);
  healthLowerBound.resize(52.5, 8);
  healthUpperBound.resize(52.5, 8);

  image(healthVariable, resizedWindowWidth / 18, resizedWindowHeight / 18);
}

function musicCheck() {
  if (audioEnabled && !backgroundMusic.isPlaying()) {
    backgroundMusic.play();
  } else if (!audioEnabled && backgroundMusic.isPlaying()) {
    backgroundMusic.pause();
  }
}

function spriteJumpAni() {
  hero.changeAni("jump");
}
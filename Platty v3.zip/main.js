/******************
 * Main js file for platformer game
 * Created by Hunter Chapman
 * Level 2 Programming assesment
 ******************/
 
// Constants
const SPRITEYOFFSET = 17;
const CAMSPRITEYOFFSET = 3;
const SPRITEWIDTHOFFSET = 2;
const WINDOWHEIGHTOFFSET = 360;
const SCALEFACTOR = 5;
const HEROFRAMEDELAY = 8;
const JUMPTOTALFRAMES = 5;
const JUMPHEIGHT = 18;
const HEROSPEED = 2.5;
const TILESIZE = 2;
const TILEXOFFSET = 400;
const LAVAHEIGHT = 16 * 0.75;
const PIXELSCALE = 'pixelated x5';

// Predefines
let hero;
let floor;
let spriteSheetHero;
let bgImage;
let plattyBackground;
let nameHasBeenInputted = false;
let heroIsJumping = false;
let jumpAniDone = false;
let riseAnimationPlayed = false;
let jumpFrameCount = 0;
let propTiles;
let groundTiles;
let swampTiles;
let level1Tiles;
let airTile;
let lavaTile;
let makeCameraStatic = false;
let sec = 0;
let deathMessagePlayed = false;
let nameInput;
let audioEnabled;
let lavaHit;
let lavaHitLow;
let lavaHitHigh;
let backgroundMusic;
let altTiles;
let dialogOpen = false;
let floatingDirtLeft;
let floatingDirtRight;
let floatingDirtSolo;
let finishFlag;
let tutorialOpen = false;
let finishMessagePlayed = false;


/* Preload function, currently just loading images, 
 * tilesheets, spritesheets, etc */
function preload() 
{
	spriteSheetHero = loadImage('/resources/questKid.png');
	bgImage = loadImage('/resources/loginPageBackground.jpeg');
	plattyBackground = loadImage('/resources/gameBackground.png');
	swampTiles = loadImage('/resources/tilesets/swampTiles.png');
	groundTiles = loadImage('/resources/tilesets/groundTiles.png');
	propTiles = loadImage('/resources/tilesets/propTiles.png');
	airTile = loadImage('/resources/tilesets/air.png');
	lavaTile = loadImage('resources/tilesets/lava.png');
	altTiles = loadImage('/resources/tilesets/groundTiles.png');
	lavaHitLow = loadSound("https://codehs.com/uploads/3dfdda4b3e49065129b8840c7628d9ca");
	lavaHitHigh = loadSound("https://codehs.com/uploads/e9521e85ad516909f5f6c0993dac8c40");
	lavaHitNorm = loadSound("https://codehs.com/uploads/1def79641167cc982cc4a1fa93379beb");
	backgroundMusic = loadSound("https://codehs.com/uploads/b7bc2716f9b557de6ecd6f9ddf48944a"); // Find audio
    floatingDirtRight = loadImage("/resources/tilesets/floatingDirtRight.png");
    floatingDirtLeft = loadImage("/resources/tilesets/floatingDirtLeft.png");
    floatingDirtSolo = loadImage("/resources/tilesets/floatingDirtSolo.png");
    finishFlag = loadImage("/resources/tilesets/finishFlag.png");
}

// Setup function, creates canvas, sprites, and assigns animations
function setup() 
{ 
    // Get window height before it is upscaled by the PIXELSCALE in create canvas
    let unalteredWindowHeight = (windowHeight - WINDOWHEIGHTOFFSET) / SCALEFACTOR;
    let unalteredWindowWidth = windowWidth / SCALEFACTOR;
    
    // Create canvas
    cnv = new Canvas(unalteredWindowWidth, unalteredWindowHeight, PIXELSCALE);
    allSprites.pixelPerfect = true;
    console.log("Canvas is (width/height): " + canvas.w + "/" + canvas.h);
    
    // Create sprite
    hero = new Sprite(unalteredWindowWidth / SPRITEWIDTHOFFSET, unalteredWindowHeight - SPRITEYOFFSET, 32, 32, 'k');
    console.log("Hero's (sprite) X/Y coordinates are: " + hero.x + "/" + hero.y);
    hero.rotationLock = true;
    hero.spriteSheet = spriteSheetHero;
    hero.anis.offset.x = SPRITEWIDTHOFFSET;
    hero.anis.frameDelay = HEROFRAMEDELAY;
    world.gravity.y = 9.8;
	
	// Create sprite animation and assign sleeping ani to sprite
	hero.addAnis({
		run: { row: 0, frames: 8 },
		jump: { row: 1, frames: 6 },
		roll: { row: 2, frames: 5, frameDelay: 14 },
		turn: { row: 3, frames: 7 },
		stand: { row: 3, frames: 1 },
		sleeping: { row: 21, frames: 10 },
		riseFromGround: { row: 23, frames: 6 }
	});
	
    hero.changeAni('sleeping');
    hero.w = 13;
    hero.h = 30;
    hero.friction = 0;
    hero.wallCollisionHappened = false;
    hero.tutorialAlertHasPlayed = false;
}

document.addEventListener("DOMContentLoaded", function() {
  var nameInput = document.getElementById("nameInput");

  // Focus on input when user starts typing
  document.addEventListener("keydown", function() {
    nameInput.focus();
  });

  // Remove outline when input is focused
  nameInput.addEventListener("focus", function() {
    nameInput.classList.add("noOutline");
  });

  // Add outline when input is blurred
  nameInput.addEventListener("blur", function() {
    nameInput.classList.remove("noOutline");
  });
});

function audioCheck() {
    audioEnabled = document.getElementById("audio").checked;
    if (audioEnabled)
    {
        console.log("Audio has been turned on");
        if (!backgroundMusic.isPlaying())
        {
            backgroundMusic.play();
        }
    }
    else if (!audioEnabled)
    {
        console.log("Audio has been turned off");
        if (backgroundMusic.isPlaying())
        {
            backgroundMusic.pause();
        }
    }
}

// Game start Function, called on click of play button, resizes-
// canvas, adds background, removes html elements 
function startGame() {
    audioEnabled = document.getElementById("audio").checked;
    // First, check if a name has been inputted
    if (!nameInputted()) {
        document.getElementById("userNameHint").textContent = "Please enter a name containing only letters";
    }
    else if (nameInputted()) {
    // Removes Header and play button elements, they're being-
    // removed instead of hidden as when theyre hidden the canvas-
    // can't use the full screen size without scrolling otherwise
    removeElement("htmlElements");
    
    //Create new variables with accurate window width/height
    let resizedWindowHeight = windowHeight / SCALEFACTOR;
    let resizedWindowWidth = windowWidth / SCALEFACTOR;
    
   
    bgImage = plattyBackground;
    allSprites.pixelPerfect = true;
    console.log("Canvas has been resized, game started");
    // Reposition sprite 'hero' to center of new view
    hero.position.x = resizedWindowWidth / SPRITEWIDTHOFFSET;
    hero.position.y = resizedWindowHeight - SPRITEYOFFSET;
    hero.changeAni('riseFromGround');
	hero.animation.looping = false;
	riseAnimationPlayed = true;
	// Calls the function that creates the tiles
    startLevel1();
     // Remove canvas and recreate it with new values because
    // resizeCanvas() doesn't work for some reason
    canvas.remove()
    cnv = new Canvas(resizedWindowWidth, resizedWindowHeight, PIXELSCALE);
    hero.cameraFollowY = true;
    hero.cameraFollowX = true;
    hero.collider = 'dynamic';
    }
}

function startLevel1() {
    //Create new variables with accurate window width/height
    let resizedWindowHeight = windowHeight / SCALEFACTOR;
    let resizedWindowWidth = windowWidth / SCALEFACTOR;
    let xCoord = hero.position.x - TILEXOFFSET;
    let yCoord = resizedWindowHeight - 15;
    console.log("creating tiles for first level")
    swampGrass = new Group();
    swampGrass.tile = 's';
    swampGrass.collider = 'static';
    swampGrass.spriteSheet = swampTiles;
    swampGrass.addAni({ w: 16, h: 16, row: 0, col: 1 });
    
    swampDirt = new Group();
    swampDirt.tile = 'd';
    swampDirt.collider = 'static';
    swampDirt.spriteSheet = swampTiles;
    swampDirt.addAni({ w: 16, h: 16, row: 1, col: 1 });
    
    grassLeftCorner = new Group();
    grassLeftCorner.tile = 'l';
    grassLeftCorner.collider = 'static';
    grassLeftCorner.spriteSheet = swampTiles;
    grassLeftCorner.addAni({ w: 16, h: 16, row: 0, col: 5 });
    
    grassBottomLeftCorner = new Group();
    grassBottomLeftCorner.tile = 'L';
    grassBottomLeftCorner.collider = 'static';
    grassBottomLeftCorner.spriteSheet = swampTiles;
    grassBottomLeftCorner.addAni({ w: 16, h: 16, row: 4, col: 7 });
    
    grassRightCorner = new Group();
    grassRightCorner.tile = 'r';
    grassRightCorner.collider = 'static';
    grassRightCorner.spriteSheet = swampTiles;
    grassRightCorner.addAni({ w: 16, h: 16, row: 0, col: 0 });
    
    grassBottomRightCorner = new Group();
    grassBottomRightCorner.tile = 'R';
    grassBottomRightCorner.collider = 'static';
    grassBottomRightCorner.spriteSheet = swampTiles;
    grassBottomRightCorner.addAni({ w: 16, h: 16, row: 4, col: 10 });
    
    leftWallCheck = new Group();
    leftWallCheck.tile = 'a';
    leftWallCheck.collider = 'none';
    leftWallCheck.image = airTile;
    leftWallCheck.w = 16;
    leftWallCheck.h = 16;
    
    cameraDisable = new Group();
    cameraDisable.tile = 'k';
    cameraDisable.collider = 'none';
    cameraDisable.image = airTile;
    cameraDisable.w = 16;
    cameraDisable.h = 16;
    
    air = new Group();
    air.tile = 'A';
    air.collider = 'static';
    air.image = airTile;
    air.w = 26;
    air.h = 16;
    
    lava = new Group();
    lava.tile = 'm';
    lava.collider = 'none';
    lavaTile.resize(16, 16);
    lava.image = lavaTile;
    lavaHitNorm.audioCount = 0;
    lavaHitHigh.audioCount = 0;
    lavaHitLow.audioCount = 0;
    
    floatGrassLeft = new Group();
    floatGrassLeft.tile = 'f';
    floatGrassLeft.collider = 'static';
    floatingDirtLeft.resize(16, 16);
    floatGrassLeft.image = floatingDirtLeft;
    
    floatGrassRight = new Group();
    floatGrassRight.tile = 'F';
    floatGrassRight.collider = 'static';
    floatingDirtRight.resize(16, 16);
    floatGrassRight.image = floatingDirtRight;
    
    floatGrassSolo = new Group();
    floatGrassSolo.tile = 'D';
    floatGrassSolo.collider = 'static';
    floatingDirtSolo.resize(16, 16);
    floatGrassSolo.image = floatingDirtSolo;
    
    finishFlagTile = new Group();
    finishFlagTile.tile = 'T';
    finishFlag.resize(40, 35);
    finishFlagTile.collider = 'none';
    finishFlagTile.image = finishFlag;
    finishFlagTile.w = 16;
    finishFlagTile.h = 16;
    
    level1Tiles = new Tiles(
        [
            '.......A........ka............................................................................ak........A...',
            '.......A........ka............................................................................ak........A...',
            '.......A........ka....................................................................T.......ak........A...',
            '.......A........ka....................................................................D.......ak........A...',
            '.......A........ka..............................................................D.............ak........A...',
            '.......A........ka........................................................fF..................ak........A...',
            '.......A........ka.................................................D..........................ak........A...',
            '.......A........ka..........................................fF................................ak........A...',
            '.......A........ka...................................fF.......................................ak........A...',
            '.......A........ka............................................................................ak........A...',
            'ssssssssssssssssssssssssssssssssssssssssslmmrsssssslmmmrssssslmmmmmrssssssssslmmmrssssssssssssssssssssssssss',
            'dddddddddddddddddddddddddddddddddddddddddLssRddddddLsssRdddddLsssssRdddddddddLsssRdddddddddddddddddddddddddd',
            'dddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddd',
            'dddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddd',
            'dddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddd',
            'dddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddd',
            'dddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddd',
            'dddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddd',
            'dddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddd'
        ],
        xCoord, yCoord,
        16, 16
    );
}

// Function that utilises jQuery to bring a pop up dialogue to the screen
// credit to ChatGPT for the base of the jQuery function as i wouldn't have
// even known where to start otherwise
// Note: Dialog is spelled without the -ue as it seems to break jQuery when spelt with
function settingsDialog() {
  // Create a div element to hold the dialog content
  let dialogContent = 
    '<div id="dialog" title="Settings">' +
    '<input style="margin: 0; auto"type="checkbox" id="musicEnabled">' +
    '<label for="musicEnabled">  Music enabled</label>' +
    '</div>';

  // Append the dialog content to the body
  $('body').append(dialogContent);

  // Change the value of the checkbox on open to checked/unchecked
  // dependent on the value of the audioEnabled variable (bool)
  $('#musicEnabled').prop('checked', audioEnabled);

  // Bind a function to the checkbox's change event to update audioEnabled
  $('#musicEnabled').change(function() {
    audioEnabled = this.checked;
    console.log("Music enabled: " + audioEnabled);
  });
  
  // Initialize the dialog
  $('#dialog').dialog({
    autoOpen: true,
    modal: true,
    buttons: [], // Empty buttons to remove "Save" button

    close: function() {
      $(this).dialog("destroy").remove(); // Remove dialog from DOM after closing
    }
  });
  $('<button>').appendTo('#dialog').focus().remove();
}

function tutorialDialogueFunc() {
    tutorialOpen = true;
    let tutorialDialogue =
        '<div id="dialog" title="Tutorial">' +
        '<h1 style="text-align: center">Tutorial</h1>' +
        '<p style="text-align: center">Welcome to the tutorial level ' + nameInput + ', in this, you will practice movement, use the arrow keys to move around and jump, and avoid the lava, it won\'t kill you, but it\'ll hurt!<br><br>When you get to the flag at the end of the level, walk into it to complete that level!</p>' +
        '</div>';
    $('body').append(tutorialDialogue)
    
    // Initialize the dialog
    $('#dialog').dialog({
    autoOpen: true,
    modal: true,
    buttons: {
    "Ok": function() {
        tutorialOpen = false;
        $(this).dialog("close");
    }
},
    close: function() {
    $(this).dialog("destroy").remove(); // Remove dialog from DOM after closing
    }
});
}

// Function that's called whenever the window resizes that adjusts the location
// of the sprite, tiles, etc
function windowResized() {
    // Create new variables with accurate window width/height
    let resizedWindowHeight = windowHeight / SCALEFACTOR;
    let resizedWindowWidth = windowWidth / SCALEFACTOR;
    let heroPreviousX = hero.position.x;
    let heroPreviousY = hero.position.y;
    console.log("Window resized");
    // Remove canvas and recreate it with new values because
    // resizeCanvas() doesn't work for some reason
    canvas.remove()
    cnv = new Canvas(resizedWindowWidth, resizedWindowHeight, PIXELSCALE);
    allSprites.pixelPerfect = true;
    // Reposition sprite 'hero' to center of new view
    if (!hero.cameraFollowX && !hero.cameraFollowY)
    {
        hero.position.x = resizedWindowWidth / SPRITEWIDTHOFFSET;
    }
    else if (hero.cameraFollowX && hero.cameraFollowY)
    {
        hero.position.x = heroPreviousX;
        hero.position.y = heroPreviousY;
    }
}

// Function to remove an html element when called
function removeElement(idToRemove) {
    let element = document.getElementById(idToRemove);
    return element.parentNode.removeChild(element);
}

// Function to check whether a name has been inputted into the input box on call,
// and return the value true or false respective of whether a name is present
function nameInputted() {
    nameInput = document.getElementById("nameInput").value;
    if (nameInput === "" || nameInput === " " || nameInput === '' || nameInput === ' ' || nameInput === null) 
    {
        return false;
    }
    else if (nameInput.length > 0)
    {
        if (nameIsValid(nameInput))
        {
            nameHasBeenInputted = true;
            return true;
        }
        else
        {
            return false;
        }
    }
}

// Function to check whether the inputted name contains only letters
// regex is funky and confusing so i don't claim this as my own code,
// credits are below.
function nameIsValid(name) {
    // Credit: geeksforgeeks.org for the regex code
    let letterTest = /^[a-zA-Z]+$/;
    if (letterTest.test(name))
    {
        return true;
    }
    else if (!letterTest.test(name))
    {
        return false;
    }
}

// p5play draw function, runs once 
function draw() {
	clear();
	background(bgImage);
	if (hero.cameraFollowY)
	{
    	camera.y = hero.y - CAMSPRITEYOFFSET;
	}
	if (hero.cameraFollowX)
	{
	    camera.x = hero.x;
	}
    if(riseAnimationPlayed)
    {
    	if(kb.pressing("ArrowLeft"))
    	{
            hero.mirror.x = true;
            hero.vel.x = -HEROSPEED;
            hero.changeAni('run');
    	}
    	if(kb.released("ArrowLeft"))
    	{
    	    hero.vel.x = 0;
    	    hero.changeAni('stand');
    	}
    	if(kb.pressing("ArrowRight"))
    	{
            hero.mirror.x = false;
            hero.vel.x = HEROSPEED;
            hero.changeAni('run');
    	}
    	if(kb.released("ArrowRight"))
    	{
    	    hero.vel.x = 0;
    	    hero.changeAni('stand');
    	}
    	if(kb.pressing("ArrowUp"))
    	{
            if(hero.vel.y === 0){
            spriteJumpAni();
            hero.vel.y = JUMPHEIGHT;
            }
    	}
    	if(hero.colliding(level1Tiles) == true)
    	{
    	    //console.log(hero.colliding(floor));
    	    hero.changeAni('stand');
    	    hero.isJumping = false;
    	}
    	if(hero.overlap(cameraDisable) == true){
    	    hero.cameraFollowX = false;
    	}
    	if(hero.overlap(leftWallCheck) == true)
    	{
    	    hero.cameraFollowX = true;
    	}
    	if(hero.colliding(level1Tiles) == true && !hero.tutorialAlertHasPlayed)
	    {
	        tutorialDialogueFunc();
	        //alert("Welcome to the tutorial level " + nameInput + ", in this, you will practice movement, use the arrow keys to move around and jump, and avoid the lava, it won't kill you immediately, but it'll hurt!");
	        //alert("When you get to the flag at the end of the level, walk into it to complete that level!")
	        hero.tutorialAlertHasPlayed = true;
    	}
    	if(hero.overlapping(lava))
    	{
    	    sec++;
    	    console.log(sec);
    	}
    	if(sec >= 160)
    	{
    	    let resetWindowHeight = windowHeight / SCALEFACTOR;
    	    let resetWindowWidth = windowWidth / SCALEFACTOR;
    	    hero.position.x = resetWindowWidth / SPRITEWIDTHOFFSET;
    	    hero.position.y = resetWindowHeight;
    	    if(!deathMessagePlayed)
    	    {
    	    alert("Sorry " + nameInput + ", you died! Resetting you to the start of your current level.");
    	    deathMessagePlayed = true;
    	    }
    	}
    	if(sec >= 10 && sec <= 20)
    	{
    	    hero.tint = color(255, 0, 0);
    	    if (audioEnabled && lavaHitNorm.audioCount < 1)
    	    {
    	        lavaHitNorm.play();
    	        lavaHitNorm.audioCount = 1;
    	    }
    	}
    	else if(sec >= 40 && sec <= 60)
    	{
    	    hero.tint = color(255, 0, 0);
    	    if (audioEnabled && lavaHitNorm.audioCount < 1)
    	    {
    	        lavaHitNorm.play();
    	        console.log("lava hit played again");
    	        lavaHitNorm.audioCount = 1;
    	    }
    	}
    	else if(sec >= 80 && sec <= 100)
    	{
    	    hero.tint = color(255, 0, 0);
    	    if (audioEnabled && lavaHitLow.audioCount < 1)
    	    {
    	        lavaHitLow.play();
    	        lavaHitLow.audioCount = 1;
    	    }
    	}
    	else if(sec >= 120 && sec <= 140)
    	{
    	    hero.tint = color(255, 0, 0);    	    
    	    if (audioEnabled && lavaHitHigh.audioCount < 1)
    	    {
    	        lavaHitHigh.play();
    	        lavaHitHigh.audioCount = 1;
    	    }
    	}
    	else
    	{
    	    lavaHitNorm.audioCount = 0;
    	    lavaHitLow.audioCount = 0;
    	    lavaHitHigh.audioCount = 0;
    	    hero.tint = color(255);
    	}
    	if(!hero.overlapping(lava))
    	{
    	    sec = 0;
    	    deathMessagePlayed = false;
    	}
    	if(kb.pressed("escape"))
    	{
    	    if(tutorialOpen)
    	    {
    	        $("#dialog").dialog("destroy").remove();
    	        tutorialOpen = false;
    	    }
    	    else if(dialogOpen)
    	    {
    	        $("#dialog").dialog("destroy").remove();
    	        dialogOpen = false;
    	    }
    	    else if (!dialogOpen)
    	    {
    	        settingsDialog();
    	        dialogOpen = true;
    	    }
    	}
    	if (hero.collides(floatGrassSolo))
    	{
    	    console.log("Colliding with grass, checking for flag collision")
    	    if (hero.overlapping(finishFlagTile) && !finishMessagePlayed)
    	    {
    	    console.log("Finish reached!");
    	    alert("Congratulations, You passed the level!");
    	    finishMessagePlayed = true;
    	    }
    	}
        musicCheck();
    }
    else if (!riseAnimationPlayed)
    {
        if(kb.pressed("Enter"))
        {
            startGame();
        }
    }
}

function musicCheck() {
    if (audioEnabled && !backgroundMusic.isPlaying())
    {
        backgroundMusic.play();
    }
    else if (!audioEnabled && backgroundMusic.isPlaying())
    {
        backgroundMusic.pause();
    }
}

function spriteJumpAni() {
    hero.changeAni('jump');
}